DELETE 
FROM E_ADS_IRR_INDEX_VALUE
WHERE INDEX_ID IN ('OR02002',
'OR02003',
'OR02034',
'OR02004',
'OR02006',
'OR04002',
'OR04003',
'OR04005',
'OR04006',
'OR04007',
'OR04009',
'OR04010')
AND TO_CHAR(LOAD_DT,'YYYYMMDD') = 20190715
AND CHANNEL_ID <> 'FC';
commit;

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'AD', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'BK', 116.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'GP', 59.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'RP', 73.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'AD', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'BK', 87.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'GP', 53.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'RP', 78.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'BK', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'BK', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'RP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'BK', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'BK', 34.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'BK', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'BK', 96.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'GP', 19.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'BK', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'BK', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'GP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'BK', 24.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'GP', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'RP', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'GP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'RP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'RP', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'BK', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'BK', 50.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'BK', 19.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'RP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'AD', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'BK', 137.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'GP', 52.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'RP', 56.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'BK', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'BK', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'AD', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'BK', 74.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'GP', 24.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'RP', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'BK', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'GP', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'RP', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'GP', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'GP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'RP', 15.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'BK', 39.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'RP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'BK', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'GP', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'RP', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'GP', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'GP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'RP', 15.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'BK', 39.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'RP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

commit;

DELETE FROM E_ADS_EMPLOYEE_LOSS;
commit;

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59340F70DEE053AC13011270DE', 'AD', '8601', 1, 5, 0, '20%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341070DEE053AC13011270DE', 'BK', '8601', 8, 7, 0, '114.29%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341170DEE053AC13011270DE', 'CS', '8601', 5, 4, 0, '125%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341270DEE053AC13011270DE', 'FC', '8601', 2, 13, 0, '15.38%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341370DEE053AC13011270DE', 'GP', '8601', 3, 9, 0, '33.33%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341470DEE053AC13011270DE', 'RP', '8601', 0, 4, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341570DEE053AC13011270DE', 'AD', '8602', 0, 1, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341670DEE053AC13011270DE', 'BK', '8602', 2, 26, 0, '7.69%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341770DEE053AC13011270DE', 'CS', '8602', 1, 6, 0, '16.67%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341870DEE053AC13011270DE', 'FC', '8602', 7, 35, 0, '20%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341970DEE053AC13011270DE', 'GP', '8602', 1, 24, 0, '4.17%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341A70DEE053AC13011270DE', 'RP', '8602', 0, 7, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341B70DEE053AC13011270DE', 'AD', '8603', 0, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341C70DEE053AC13011270DE', 'BK', '8603', 0, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341D70DEE053AC13011270DE', 'CS', '8603', 2, 3, 0, '66.67%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341E70DEE053AC13011270DE', 'FC', '8603', 1, 7, 0, '14.29%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59341F70DEE053AC13011270DE', 'GP', '8603', 3, 6, 0, '50%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342070DEE053AC13011270DE', 'RP', '8603', 1, 4, 0, '25%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342170DEE053AC13011270DE', 'AD', '8604', 3, 9, 0, '33.33%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342270DEE053AC13011270DE', 'BK', '8604', 27, 28, 0, '96.43%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342370DEE053AC13011270DE', 'CS', '8604', 1, 4, 0, '25%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342470DEE053AC13011270DE', 'FC', '8604', 11, 71, 0, '15.49%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342570DEE053AC13011270DE', 'GP', '8604', 6, 20, 0, '30%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342670DEE053AC13011270DE', 'RP', '8604', 0, 15, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342770DEE053AC13011270DE', 'AD', '8605', 2, 6, 0, '33.33%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342870DEE053AC13011270DE', 'BK', '8605', 10, 13, 0, '76.92%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342970DEE053AC13011270DE', 'CS', '8605', 2, 5, 0, '40%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342A70DEE053AC13011270DE', 'FC', '8605', 16, 40, 0, '40%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342B70DEE053AC13011270DE', 'GP', '8605', 4, 18, 0, '22.22%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342C70DEE053AC13011270DE', 'RP', '8605', 1, 11, 0, '9.09%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342D70DEE053AC13011270DE', 'AD', '8606', 1, 12, 0, '8.33%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342E70DEE053AC13011270DE', 'BK', '8606', 0, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59342F70DEE053AC13011270DE', 'CS', '8606', 0, 7, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343070DEE053AC13011270DE', 'FC', '8606', 10, 45, 0, '22.22%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343170DEE053AC13011270DE', 'GP', '8606', 2, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343270DEE053AC13011270DE', 'RP', '8606', 2, 15, 0, '13.33%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343370DEE053AC13011270DE', 'AD', '8607', 0, 4, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343470DEE053AC13011270DE', 'BK', '8607', 7, 8, 0, '87.5%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343570DEE053AC13011270DE', 'CS', '8607', 0, 3, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343670DEE053AC13011270DE', 'FC', '8607', 7, 26, 0, '26.92%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343770DEE053AC13011270DE', 'GP', '8607', 2, 7, 0, '28.57%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343870DEE053AC13011270DE', 'RP', '8607', 0, 6, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343970DEE053AC13011270DE', 'AD', '8608', 0, 5, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343A70DEE053AC13011270DE', 'BK', '8608', 34, 59, 0, '57.63%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343B70DEE053AC13011270DE', 'CS', '8608', 0, 6, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343C70DEE053AC13011270DE', 'FC', '8608', 6, 28, 0, '21.43%', 1.50);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343D70DEE053AC13011270DE', 'GP', '8608', 2, 5, 0, '40%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343E70DEE053AC13011270DE', 'RP', '8608', 0, 8, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59343F70DEE053AC13011270DE', 'BK', '8609', 10, 24, 0, '41.67%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344070DEE053AC13011270DE', 'CS', '8609', 1, 3, 0, '33.33%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344170DEE053AC13011270DE', 'FC', '8609', 0, 3, 0, '0%', 3.00);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344270DEE053AC13011270DE', 'GP', '8609', 1, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344370DEE053AC13011270DE', 'RP', '8609', 1, 2, 0, '50%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344470DEE053AC13011270DE', 'AD', '8610', 2, 2, 0, '100%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344570DEE053AC13011270DE', 'BK', '8610', 3, 3, 0, '100%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344670DEE053AC13011270DE', 'CS', '8610', 3, 3, 0, '100%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344770DEE053AC13011270DE', 'FC', '8610', 7, 16, 0, '43.75%', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344870DEE053AC13011270DE', 'GP', '8610', 1, 0, 0, '', null);

insert into E_ADS_EMPLOYEE_LOSS (UUID, CHANNEL, ORG_NAME, QUITNUM, EMPLOYEE_NUM, ADD_NUM, QUIT_RATE, SCORE)
values ('8E584C59344970DEE053AC13011270DE', 'RP', '8610', 1, 3, 0, '33.33%', null);
commit;