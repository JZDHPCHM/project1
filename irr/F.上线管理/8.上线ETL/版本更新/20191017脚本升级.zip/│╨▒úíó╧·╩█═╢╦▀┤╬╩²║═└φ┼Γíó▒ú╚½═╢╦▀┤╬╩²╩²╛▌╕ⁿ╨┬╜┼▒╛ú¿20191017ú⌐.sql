--评估期保险公司关于承保、销售业务线的投诉次数
--评估期保险公司关于理赔、保全业务线的投诉次数
DELETE FROM E_ADS_IRR_INDEX_VALUE T 
WHERE T.INDEX_ID IN ('OR06005','OR02011')
AND TO_CHAR(T.LOAD_DT,'YYYYMMDD') = '20191015';
COMMIT;


insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR06005', '86', '', 4.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02011', '86', '', 508.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

COMMIT;