insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8601', '', 5.2722, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8605', '', 76.0218, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8606', '', 71.0216, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8603', '', 9.1239, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8608', '', 81.9010, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8607', '', 33.9203, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8610', '', 12.8271, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8609', '', 6.1897, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8604', '', 72.3235, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8611', '', 0.6252, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08002', '8602', '', 41.8506, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8601', '', 9.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8602', '', 44.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8603', '', 3.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8604', '', 232.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8605', '', 143.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8606', '', 184.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8607', '', 9.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8608', '', 112.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8609', '', 9.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8610', '', 23.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08005', '8611', '', 8.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8601', '', 31.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8602', '', 218.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8603', '', 65.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8604', '', 608.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8605', '', 447.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8606', '', 465.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8607', '', 114.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8608', '', 575.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8609', '', 49.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8610', '', 59.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08006', '8611', '', 12.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8601', '', 2707703.3000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8602', '', 4339540.3700, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8603', '', 680189.9500, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8604', '', 8225743.8400, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8605', '', 7168234.8500, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8606', '', 9257006.5900, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8607', '', 3115382.1300, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8608', '', 10453364.2600, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8609', '', 477116.2900, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8610', '', 850539.4000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08012', '8611', '', 531405.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8601', '', 50.4000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8602', '', 610.8000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8603', '', 4274.2800, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8604', '', 29015.9000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8605', '', 11123.6100, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8606', '', 10812.3800, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8607', '', 1843.1000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8608', '', 32001.8900, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8609', '', 2401.1200, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8610', '', 3686.5600, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08011', '8611', '', 0.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8601', '', 31.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8602', '', 217.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8603', '', 65.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8604', '', 607.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8605', '', 447.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8606', '', 465.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8607', '', 114.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8608', '', 574.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8609', '', 49.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8610', '', 59.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08009', '8611', '', 12.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8601', '', 31.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8605', '', 447.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8606', '', 465.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8603', '', 65.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8608', '', 574.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8607', '', 114.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8610', '', 59.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8609', '', 49.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8604', '', 607.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8611', '', 12.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08008', '8602', '', 217.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8601', '', 31.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8602', '', 217.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8603', '', 65.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8604', '', 607.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8605', '', 447.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8606', '', 465.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8607', '', 114.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8608', '', 574.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8609', '', 49.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8610', '', 59.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

insert into E_MDS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR08003', '8611', '', 12.0000, '2020Q1', to_date('26-04-2020', 'dd-mm-yyyy'));

COMMIT;
