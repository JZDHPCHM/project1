DROP PROCEDURE SP_MDS_COORDINATION;

CREATE PROCEDURE SP_MDS_COORDINATION(V_INDATE  IN VARCHAR2,
                                            V_RTNCODE OUT VARCHAR2,
                                            V_RTNMSG  OUT VARCHAR2) 
                                            AUTHID CURRENT_USER AS

  /**********************************************************************/
  /* Procedure Name : SP_MDS_COORDINATION                               */
  /* Developed By   : SY                                                */
  /* Developed Date : 2018-10-31                                        */
  /* MODIFIED Date : WH 2018-12-27                                      */
  /************************ Souce table *********************************/
  /* Target table   : E_MDS_IRR_INDEX_VALUE                             */
  /********************** Variable Section ******************************/
  V_EVAL_STARTTIME VARCHAR2(10); --�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(10); --�����ڽ���ʱ��
  V_START          DATE; --ִ�п�ʼʱ��
  V_END            DATE; --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER; --��¼����
  V_SQL            VARCHAR2(20000); --��̬���
  /***********************************************************************/
BEGIN
  DBMS_OUTPUT.ENABLE(1000000);
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE),
                                                 'yyyymmdd') + 1,
                                         -3),
                              'yyyymmdd');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE);
  --------------------------------ɾ������-------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR04018'' AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  V_START := SYSDATE;
  --�������ڳб��ı�������
  V_SQL := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
           SELECT ''OR04018'',
                  B.PROVINCECOMCODE,
                  DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL),
                  COUNT(NVL(BASE.POLICYNO,0)),
                   CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
                  FROM E_BDS_CCCMP_POLICYS_BASE BASE
                INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
                   ON BASE.POLICYNO = INDI.POLICYNO
                INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
                   ON BASE.POLICYNO = CASE3.POLICYNO
                LEFT JOIN E_BDS_BIDM_MGECMP B
                 ON B.LAORIGORGCODE = BASE.COMPANYNO
                WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN to_date(''' ||
           V_EVAL_STARTTIME || ''',''yyyy-mm-dd'') AND
      to_date( ''' || V_EVAL_ENDTIME ||
           ''',''yyyy-mm-dd'')
                  AND INDI.ISCFI = ''0''
                  AND INDI.ISWD = ''0''
                  AND BASE.ZACKDTE IS NOT NULL
                  AND BASE.ZACKDTE != ''99999999''
                  AND BASE.NEEDCALLBACK = ''1''
                  AND BASE.CNTTYPE NOT LIKE ''PA%''
                  AND CASE3.BACRS NOT IN (''1'', ''10'')
                  AND NOT (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
                  GROUP BY B.PROVINCECOMCODE,DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL)';
  EXECUTE IMMEDIATE V_SQL;
  DBMS_OUTPUT.PUT_LINE(V_SQL);
  COMMIT;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR04018',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  
  
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR04072''AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  ----------------------------------������־��Ϣ���---------------------------------
   --�������ڳб��ı�������
  V_SQL := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
           SELECT ''OR04072'',
                  B.PROVINCECOMCODE,
                  DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL),
                  COUNT(NVL(BASE.POLICYNO,0)),
                   CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
                  FROM E_BDS_CCCMP_POLICYS_BASE BASE
                INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
                   ON BASE.POLICYNO = INDI.POLICYNO
                INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
                   ON BASE.POLICYNO = CASE3.POLICYNO
                LEFT JOIN E_BDS_BIDM_MGECMP B
                 ON B.LAORIGORGCODE = BASE.COMPANYNO
                WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN to_date(''' ||
           V_EVAL_STARTTIME || ''',''yyyy-mm-dd'') AND
      to_date( ''' || V_EVAL_ENDTIME ||
           ''',''yyyy-mm-dd'')
                  AND INDI.ISCFI = ''0''
                  AND INDI.ISWD = ''0''
                  AND BASE.ZACKDTE IS NOT NULL
                  AND BASE.ZACKDTE != ''99999999''
                  AND BASE.NEEDCALLBACK = ''1''
                  AND BASE.CNTTYPE NOT LIKE ''PA%''
                  AND CASE3.BACRS NOT IN (''1'', ''10'')
                  AND NOT (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
                  GROUP BY B.PROVINCECOMCODE,DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL)';
  EXECUTE IMMEDIATE V_SQL;
    DBMS_OUTPUT.PUT_LINE(V_SQL);
  COMMIT;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR04072',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  ----------------------------------������־��Ϣ���---------------------------------
  
  
 --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR04017''AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --��������ͨ���绰�ط÷�ʽ����ԥ�����������Լ�طõı�������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR04017'',
                 PROVINCECOMCODE,
                 DECODE(CHANNEL,''GB'',''GP'',CHANNEL),
                 COUNT(NVL(POLICYNO, 0)),
                 CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM  (SELECT BASE.AGENTNO,
               B.PROVINCECOMCODE,
               BASE.BRANCH,
               BASE.CHANNEL,
               BASE.ENDHESDATE,
               BASE.CHDRNUM,
               BASE.POLICYNO,
               MIN(CBLIST.CALLBACKDATE) CALLBACKDATE,
               BASE.ARACDE1
          FROM E_BDS_CCCMP_POLICYS_BASE BASE
         INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
            ON BASE.POLICYNO = INDI.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
            ON BASE.POLICYNO = CASE3.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CALL_LIST CBLIST
            ON CBLIST.POLICYNO = BASE.POLICYNO
         LEFT JOIN E_BDS_BIDM_MGECMP B
            ON B.LAORIGORGCODE = BASE.COMPANYNO
         WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN to_date(''' ||
             V_EVAL_STARTTIME || ''',''yyyy-mm-dd'') AND
      to_date( ''' || V_EVAL_ENDTIME ||
             ''',''yyyy-mm-dd'')
           AND INDI.ISCFI = ''0'' --�޳�CFI
           AND INDI.ISWD = ''0'' --�޳�WD
           AND BASE.ZACKDTE IS NOT NULL --��ִ����
           AND BASE.ZACKDTE != ''99999999''
           AND BASE.NEEDCALLBACK = ''1'' --�Ƿ���Ҫ�ط�
           AND BASE.CNTTYPE NOT LIKE ''PA%''
           AND NOT
                (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
           AND CASE3.BACRS NOT IN (''0'', ''1'') --�طý�� 0�ظ�����     1δ�ص���CFI
           AND CBLIST.CALLBACKRESULT IN
               (''�绰�ط���ȫ�ɾ���'',
                ''�绰�ط������'',
                ''�绰�ط�-CS�ɾ���'',
                ''�绰�ط�CS�ɾ���'',
                ''�绰�ط���ȫ�ɾ�����Ͷ����'',
                ''�绰�ط�CS�ɾ�����Ͷ����'',
                ''�绰�ط��������Ͷ����'',
                ''�׷��Żطøɾ���'',
                ''�׷��Żط��������Ͷ����'',
                ''�����-Ͷ��δ˫¼'')
         GROUP BY B.PROVINCECOMCODE,
                  BASE.BRANCH,
                  BASE.CHANNEL,
                  BASE.ENDHESDATE,
                  BASE.CHDRNUM,
                  BASE.AGENTNO,
                  BASE.ARACDE1,
                  BASE.POLICYNO) T
 WHERE T.ENDHESDATE >=
       SUBSTR(T.CALLBACKDATE, 0, 4) || SUBSTR(T.CALLBACKDATE, 6, 2) ||
       SUBSTR(T.CALLBACKDATE, 9, 2)
 GROUP BY PROVINCECOMCODE, DECODE(CHANNEL,''GB'',''GP'',CHANNEL)';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR04017',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR04020''AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --�������ڳб��ı�������ɻطõı�������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
 SELECT ''OR04020'',
       B.PROVINCECOMCODE ,
        DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL) CHANNEL,
         count(BASE.CHDRNUM),
           CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
  FROM E_BDS_CCCMP_POLICYS_BASE BASE
  LEFT JOIN E_BDS_CCNT_CRM_CASE3 A
    ON A.CHDRCOYID = BASE.COMPANYNO || BASE.BRANCH
   AND A.CHDRNUM = BASE.CHDRNUM
 INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
    ON BASE.POLICYNO = INDI.POLICYNO
 INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
    ON BASE.POLICYNO = CASE3.POLICYNO
    LEFT JOIN E_BDS_BIDM_MGECMP B
            ON B.LAORIGORGCODE = BASE.COMPANYNO 
 WHERE (TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') >= to_date(''' ||
             V_EVAL_STARTTIME || ''',''yyyy-mm-dd'')
   AND TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') <=to_date( ''' || V_EVAL_ENDTIME || ''',''yyyy-mm-dd''))
   AND INDI.ISCFI = ''0''
   AND INDI.ISWD = ''0''
   AND BASE.ZACKDTE IS NOT NULL
   AND BASE.ZACKDTE != ''99999999''
   AND BASE.NEEDCALLBACK = ''1''
   AND BASE.CNTTYPE NOT LIKE ''PA%''
   AND CASE3.BACRS NOT IN (''1'', ''10'')
   AND NOT (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
      AND BASE.CHANNEL IN (''FC'', ''BK'', ''AD'', ''RP'', ''GB'')
      AND (CASE3.BACRS IN (''2'', ''9'') OR A.VSLRESULT = ''0'')
group BY B.PROVINCECOMCODE,DECODE(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL)';
  EXECUTE IMMEDIATE V_SQL;
    DBMS_OUTPUT.PUT_LINE(V_SQL);
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR04020',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR02009''AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --�����ڵ绰�طóɹ��ı�������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR02009'',
                 ''86'',
                 decode(CHANNEL,''GB'',''GP'',CHANNEL),
                 COUNT(NVL(POLICYNO, 0)),
                 CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM  (SELECT BASE.AGENTNO,
               B.PROVINCECOMCODE,
               BASE.BRANCH,
               BASE.CHANNEL,
               BASE.ENDHESDATE,
               BASE.CHDRNUM,
               BASE.POLICYNO,
               MIN(CBLIST.CALLBACKDATE) CALLBACKDATE,
               BASE.ARACDE1
          FROM E_BDS_CCCMP_POLICYS_BASE BASE
         INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
            ON BASE.POLICYNO = INDI.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
            ON BASE.POLICYNO = CASE3.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CALL_LIST CBLIST
            ON CBLIST.POLICYNO = BASE.POLICYNO
         LEFT JOIN E_BDS_BIDM_MGECMP B
            ON B.LAORIGORGCODE = BASE.COMPANYNO
         WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN to_date(''' ||
             V_EVAL_STARTTIME || ''',''yyyy-mm-dd'') AND
      to_date( ''' || V_EVAL_ENDTIME ||
             ''',''yyyy-mm-dd'')
           AND INDI.ISCFI = ''0'' --�޳�CFI
           AND INDI.ISWD = ''0'' --�޳�WD
           AND BASE.ZACKDTE IS NOT NULL --��ִ����
           AND BASE.ZACKDTE != ''99999999''
           AND BASE.NEEDCALLBACK = ''1'' --�Ƿ���Ҫ�ط�
           AND BASE.CNTTYPE NOT LIKE ''PA%''
           AND NOT
                (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
           AND CASE3.BACRS NOT IN (''0'', ''1'') --�طý�� 0�ظ�����     1δ�ص���CFI
           AND CBLIST.CALLBACKRESULT IN
               (''�绰�ط���ȫ�ɾ���'',
                ''�绰�ط������'',
                ''�绰�ط�-CS�ɾ���'',
                ''�绰�ط�CS�ɾ���'',
                ''�绰�ط���ȫ�ɾ�����Ͷ����'',
                ''�绰�ط�CS�ɾ�����Ͷ����'',
                ''�绰�ط��������Ͷ����'',
                ''�׷��Żطøɾ���'',
                ''�׷��Żط��������Ͷ����'',
                ''�����-Ͷ��δ˫¼'')
         GROUP BY B.PROVINCECOMCODE,
                  BASE.BRANCH,
                  BASE.CHANNEL,
                  BASE.ENDHESDATE,
                  BASE.CHDRNUM,
                  BASE.AGENTNO,
                  BASE.ARACDE1,
                  BASE.POLICYNO) T
 WHERE T.ENDHESDATE >=
       SUBSTR(T.CALLBACKDATE, 0, 4) || SUBSTR(T.CALLBACKDATE, 6, 2) ||
       SUBSTR(T.CALLBACKDATE, 9, 2)
 GROUP BY decode(CHANNEL,''GB'',''GP'',CHANNEL)';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR02009',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR02010''AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' ||
           V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
    --------------------------------��������--------------------------------
    --�����ڿ�չ�绰�طõı�������
    V_START := SYSDATE;
    V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
               INDEX_ID,
               ORG_ID,
               CHANNEL_ID,
               INDEX_VALUE,
               EVAL_DATE,
               LOAD_DT)
              SELECT ''OR02010'',
                  ''86'',
                  decode(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL),
                  COUNT(NVL(BASE.POLICYNO,0)),
                   CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
                  FROM E_BDS_CCCMP_POLICYS_BASE BASE
                INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
                   ON BASE.POLICYNO = INDI.POLICYNO
                INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
                   ON BASE.POLICYNO = CASE3.POLICYNO
                LEFT JOIN E_BDS_BIDM_MGECMP B
                 ON B.LAORIGORGCODE = BASE.COMPANYNO
                WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN to_date(''' ||
           V_EVAL_STARTTIME || ''',''yyyy-mm-dd'') AND
      to_date( ''' || V_EVAL_ENDTIME ||
           ''',''yyyy-mm-dd'')
                  AND INDI.ISCFI = ''0''
                  AND INDI.ISWD = ''0''
                  AND BASE.ZACKDTE IS NOT NULL
                  AND BASE.ZACKDTE != ''99999999''
                  AND BASE.NEEDCALLBACK = ''1''
                  AND BASE.CNTTYPE NOT LIKE ''PA%''
                  AND CASE3.BACRS NOT IN (''1'', ''10'')
                  AND NOT (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
                  GROUP BY decode(BASE.CHANNEL,''GB'',''GP'',BASE.CHANNEL)';
    EXECUTE IMMEDIATE V_SQL;
    -----------------------------------������־��Ϣ���--------------------------------
    -----------------------------------��ʼ������־��Ϣ--------------------------------
    V_RECORD_NUM := SQL%ROWCOUNT;
    V_END        := SYSDATE;
    V_RTNCODE    := '0';
    V_RTNMSG     := 'ִ�гɹ�';
    INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR02010',
     'SP_MDS_COORDINATION',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
    --------------------------------�쳣����-----------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        ROLLBACK;
        V_END     := SYSDATE;
        V_RTNCODE := '1';
        V_RTNMSG  := SQLERRM;
        INSERT INTO ETL_LOG_DETAIL
        (ID,
         INDEX_ID,
         SP_NAME,
         TABLE_NAME,
         START_TIME,
         END_TIME,
         DATA_DATE,
         RECORD_NUM,
         ERR_CODE,
         ERR_MSG)
      VALUES
        (SYS_GUID(),
         '',
         'SP_MDS_COORDINATION',
         'E_MDS_IRR_INDEX_VALUE',
         V_START,
         V_END,
         V_INDATE,
         V_RECORD_NUM,
         V_RTNCODE,
         V_RTNMSG);
      COMMIT;
   -----------------------------------������־��Ϣ���--------------------------------
      END;
END SP_MDS_COORDINATION;
;

