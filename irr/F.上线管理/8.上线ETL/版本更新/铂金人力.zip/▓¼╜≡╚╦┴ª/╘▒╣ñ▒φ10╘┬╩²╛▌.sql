DELETE FROM E_BDS_HRM_EMPLOYEESTATE WHERE DATA_DATE = '201910';
COMMIT;


insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'F_A', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'GD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'HR', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'IDSS', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'IDT', '5', '5', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'SFD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'T4_GDNo1', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'AD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'AD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'BD', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'CS', '7', '6', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'F_A', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'HR', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'IDSS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'IDT', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'SFD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'T4_DengFeg', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'T4_XigYang', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HeNan', 'T4_XinMi', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_DengFeg', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_GongYiZ', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_HNNo1', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_XinMi', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_ZhengZ1', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_ZhengZ2', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_JiaoZ', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_JiaoZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_JiaoZ', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_JiaoZ', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_KaiF', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_KaiF', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_KaiF', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSB_KaiF', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_JiaoZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_JiaoZ', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_JiaoZ', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_JiaoZ', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_JiaoZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'IDT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'BD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'T4_XinAn', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'T4_NanLe', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_SanMX', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_SanMX', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_SanMX', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HeNan', 'HNSO_SanMX', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', '', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'ACT', '12', '12', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'ACT_SD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'AD', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'AO', '17', '17', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'BAO', '2', '3', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'BD', '9', '9', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'CAO', '17', '17', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'COM_OR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'CS', '38', '38', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'EMT', '11', '11', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'FM', '20', '20', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'GD', '8', '8', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'HI', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'HR', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'IA', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'ID', '19', '18', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'IDT', '9', '9', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'IM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'INV', '25', '25', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'IT', '38', '38', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'LEG_COM', '9', '9', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'LEGAL', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'MKT', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PD_MKT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PI', '15', '15', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PP_PM_GP', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'PRO', '16', '16', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'AD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'AD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'BD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'COM_OR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'COM_RM', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'CS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'F_A', '3', '2', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'HR', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'IDSD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'IDSS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'MKT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'SFD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'T4_ChangPi', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'T4_ChaoYag', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'BeiJing', 'BeiJing', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'BD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'COM_RM', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'CS', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'F_A', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'GMO', '2', '3', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'HR', '2', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'IDSS', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'IDT', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'MKT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'SFD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'T4_DaLianB', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'T4_JinZhou', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'T4_KaiFaQu', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'DaLian', 'DaLian', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GD_GuangZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GD_GuangZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GD_GuangZ', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GD_GuangZ', 'IDT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'T4_SanShui', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'T4_ShunDe', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_JMen', 'GA', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_JMen', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_JMen', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_JMen', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_ZhaoQ', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_ZhaoQ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_ZhaoQ', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSB_ZhaoQ', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GDSO_FOS', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'AD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'GuangDong', 'GuangDong', 'CS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'T4_DaFeng', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'T4_SheYang', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'GA', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'IDSD', '2', '2', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_Chang', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_DiY', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_DiY', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanJ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanJ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanJ', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanJ', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'T4_RuDong', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'T4_TongZho', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'GA', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'GD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'IDSD', '1', '2', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'IDT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'T4_KunShan', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'GA', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_TaiZh', 'IDT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_WuXi', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', '', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'IDT', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'T4_PeiXian', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'T4_XinYi', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YanC', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YanC', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YanC', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YanC', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'GMO', '2', '1', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'IDT', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'T4_DongGaS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_JinZh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_JinZh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_JinZh', 'IDSD', '1', '2', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_JinZh', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'IDT', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'T4_SYNo1', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'T4_BaYuQuS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'IDSD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_DanDo', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_DanDo', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_DanDo', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_FuSh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_JinZh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_JinZh', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_JinZh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_LiaoY', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_LiaoY', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_LiaoY', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_LiaoY', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'T4_ChangTu', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSO_YingK', 'T4_SO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'AD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'COM_RM', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'CS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'F_A', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'GA', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'GD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'HR', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'IDSS', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'SFD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_ChengYa', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_JiMo', '2', '3', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_LaiXi', '3', '3', '1', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_PingDuS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_QDNo2', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'QingDao', 'QingDao', 'T4_QDShiNa', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_DeZh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_DeZh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_DeZh', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_DeZh', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_JiNan', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_JiNan', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_JiNan', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_JiNan', 'IDT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'GA', '1', '2', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'T4_FeiChen', '3', '3', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiF', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiF', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiF', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiF', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiF', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'T4_WenDeng', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'T4_ZhouChe', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_JiNan', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'T4_CangSha', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'T4_LanLing', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_TaiAn', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_TaiAn', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_TaiAn', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiF', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YanC', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JSSO_YangZ', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'AD', '8', '8', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'COM_OR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'CS', '8', '8', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'F_A', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'HR', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'IDSD', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'IDSS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'IDT', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'MKT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'SFD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'T4_ChangTu', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'T4_DaShiQi', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'T4_DongGan', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'T4_ShenHe', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'T4_WangHua', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_AnSh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_AnSh', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_AnSh', 'IDSD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_AnSh', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'RM', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'RP_BRD', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'SBP_PD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'SD', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'SMD_No1', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'SMD_No2', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'HO', 'HO', 'SPM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'AD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'AD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'CS', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'F_A', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'GA', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'HR', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'IDPID', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'IDSS', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'SFD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'T4_JiangDu', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'T4_JSNo1', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'T4_RuDong', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'T4_SheYang', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JiangSu', 'T4_YiXing', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'IDSD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_JingJ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'GA', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_NanCh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'AD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'BD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'COM_OR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'CS', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'F_A', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'GMO', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'HR', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'IDSD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'IDSS', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'IDT', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'SFD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'T4_JinJiag', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SiChuan', 'T4_QingBai', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'AD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'BD', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'COM'||'&'||'OR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'CS', '7', '8', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'F'||'&'||'A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'F_A', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'GA', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'GD', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'GMO', '4', '4', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'HB_BMD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'HR', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'IDSS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'IDT', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'IT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'MKT', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'SFD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'SUD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_BaoDi', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_BinHai', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_BinHaiS', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_DaGang', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_DaGangS', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_DongLi', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_JinNan', '4', '4', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_JiXian', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_JiXianS', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_KongGag', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_No1', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_No2', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_No3', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_WuQing', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TianJin', 'T4_ZiMaoQu', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'AD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'CS', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'F_A', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'TianJin', 'TJSB_ShiJZ', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'AD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'BD', '4', '4', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'ID', '8', '8', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'BeiJing', 'BeiJing', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'DaLian', 'DaLian', 'BD', '18', '18', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'DaLian', 'DaLian', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'DaLian', 'DaLian', 'ID', '2', '2', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'DaLian', 'DaLian', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'DaLian', 'DaLian', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GD_GuangZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GDSB_FOS', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GDSB_FOS', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GDSB_FOS', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GDSB_FOS', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GDSO_FOS', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GuangDong', 'AD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GuangDong', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GuangDong', 'GD', '3', '3', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GuangDong', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'GuangDong', 'GuangDong', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'AD', '1', '1', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'BD', '22', '22', '3', '3', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'ID', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HeNan', 'RP_BRD', '11', '11', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HN_LuoY', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HNSO_JiaoZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HNSO_JiaoZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HNSO_LuoY', 'BD', '11', '14', '3', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'HeNan', 'HNSO_LuoY', 'ID', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JiangSu', 'AD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JiangSu', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JiangSu', 'GD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JiangSu', 'ID', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JiangSu', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JS_YanCheg', 'AD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JS_YanCheg', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JS_YanCheg', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_Chang', 'AD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_Chang', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_Chang', 'GD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_Chang', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_Chang', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_NanT', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_NanT', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_NanT', 'ID', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_NanT', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_NanT', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'AD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'GD', '1', '1', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_TaiZh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_TaiZh', 'RP_BRD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'AD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'ID', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YanC', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YanC', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'AD', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LiaoNing', 'RP_BRD', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_AnSh', 'RP_BRD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_DanDo', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_DanDo', 'RP_BRD', '1', '2', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_FuSh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_FuSh', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_JinZh', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_ShenY', 'ID', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSB_YingK', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_AnSh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_AnSh', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_BenXi', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_BenXi', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_DanDo', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_FuSh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_JinZh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_JinZh', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_LiaoY', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_LiaoY', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'LiaoNing', 'LNSO_YingK', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'QingDao', 'QingDao', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'QingDao', 'QingDao', 'GD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'QingDao', 'QingDao', 'ID', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'QingDao', 'QingDao', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'QingDao', 'QingDao', 'RP_BRD', '4', '5', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'ID', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_JiNan', 'ID', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_TaiAn', 'ID', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_TaiAn', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'GD', '2', '2', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'ID', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_WeiH', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'CoS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'F_A', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'IDSD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'T4_YanTaiQ', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_Zhang', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'HR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'T4_ZhouCun', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'T4_ZiBoSQ', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'T4_ZiChuan', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'AD', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'BD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'COM', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'COM_RM', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'CS', '6', '5', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'F_A', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'GA', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'HR', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'IDSD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'IDSS', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'IDT', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'RP_BRD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'SFD', '2', '2', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'T4_CangSha', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'T4_JiNan', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'T4_ZhagQiu', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'ShanDong', 'ShanDong', 'T4_ZhouChe', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'T4_QianWei', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SC_ChengD', 'T4_JinJiag', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_MeiSh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_MeiSh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_MeiSh', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'IDSD', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'IDT', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'T4_XiChong', '3', '3', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_ZiGon', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_ZiGon', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_ZiGon', 'IDSD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSB_ZiGon', 'IDT', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'GA', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'GMO', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'RP_BRD', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'GDSB_LeS', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'GDSB_LeS', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'GD', '2', '1', '0', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSB_ZiGon', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSB_ZiGon', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_JingJ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_NanCh', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SCSO_NanCh', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SiChuan', 'AD', '3', '3', '1', '1', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SiChuan', 'BD', '8', '8', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SiChuan', 'GD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SiChuan', 'ID', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'SiChuan', 'SiChuan', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'BD', '28', '30', '2', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'GD', '19', '19', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'GMO', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'ID', '28', '29', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TianJin', 'RP_BRD', '8', '9', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TJSB_ShiJZ', 'AD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'TianJin', 'TJSB_ShiJZ', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiN', 'BD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiN', 'GD', '3', '4', '1', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiN', 'ID', '12', '12', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiN', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiN', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_JiNan', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_YanT', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_YanT', 'GD', '4', '4', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_YanT', 'ID', '12', '12', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_YanT', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_YanT', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'ID', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'PR', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'RP_BRD', '1', '1', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_Zhang', 'ID', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'BD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'GD', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'ID', '7', '7', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'RP_BRD', '2', '2', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'AD', '6', '6', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'BD', '22', '21', '1', '2', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'CS', '0', '0', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'GD', '5', '5', '0', '0', '201910');

insert into E_BDS_HRM_EMPLOYEESTATE 
values ('30', 'ShanDong', 'ShanDong', 'ID', '0', '0', '0', '0', '201910');

COMMIT;