DELETE FROM E_BDS_HRM_EMPLOYEEDEGREE WHERE DATA_DATE = '201910';
COMMIT;


insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'AD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'BD', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'GD', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'ID', '8', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'BeiJing', 'BeiJing', 'RP_BRD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'DaLian', 'DaLian', 'BD', '16', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'DaLian', 'DaLian', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'DaLian', 'DaLian', 'ID', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'DaLian', 'DaLian', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'DaLian', 'DaLian', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GD_GuangZ', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GDSB_FOS', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GDSB_FOS', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GDSB_FOS', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GDSB_FOS', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GDSO_FOS', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GuangDong', 'AD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GuangDong', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GuangDong', 'GD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GuangDong', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'GuangDong', 'GuangDong', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'AD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'BD', '13', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HeNan', 'RP_BRD', '11', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HN_LuoY', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HNSO_JiaoZ', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HNSO_JiaoZ', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HNSO_LuoY', 'BD', '10', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'HeNan', 'HNSO_LuoY', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JiangSu', 'AD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JiangSu', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JiangSu', 'GD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JiangSu', 'ID', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JiangSu', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JS_YanCheg', 'AD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JS_YanCheg', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JS_YanCheg', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_Chang', 'AD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_Chang', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_Chang', 'GD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_Chang', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_Chang', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_NanT', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_NanT', 'GD', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_NanT', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_NanT', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_NanT', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'AD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_SuZ', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_TaiZh', 'RP_BRD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_WuXi', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'AD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'ID', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_XuZ', 'RP_BRD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YanC', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YanC', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'JiangSu', 'JSSO_YangZ', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'AD', '6', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LiaoNing', 'RP_BRD', '6', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_AnSh', 'RP_BRD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_DanDo', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_FuSh', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_FuSh', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_JinZh', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_ShenY', 'ID', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSB_YingK', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_AnSh', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_AnSh', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_BenXi', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_BenXi', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_DanDo', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_FuSh', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_JinZh', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_JinZh', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_LiaoY', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_LiaoY', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_TieL', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'LiaoNing', 'LNSO_YingK', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'QingDao', 'QingDao', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'QingDao', 'QingDao', 'GD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'QingDao', 'QingDao', 'ID', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'QingDao', 'QingDao', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'QingDao', 'QingDao', 'RP_BRD', '5', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_DeZh', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_JiNan', 'ID', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_TaiAn', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'GD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiF', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSB_WeiH', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiN', 'BD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiN', 'GD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiN', 'ID', '6', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiN', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiN', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_JiNan', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_LinYi', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiF', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_WeiH', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_YanT', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_YanT', 'GD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_YanT', 'ID', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_YanT', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_YanT', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZaoZh', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_Zhang', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'ID', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'SDSO_ZiBo', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'AD', '6', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'BD', '15', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'CS', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'GD', '4', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'ShanDong', 'ShanDong', 'RP_BRD', '5', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'GDSB_LeS', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'GDSB_LeS', 'RP_BRD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSB_NanCh', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSB_ZiGon', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSB_ZiGon', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_DaZho', 'RP_BRD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_JingJ', 'ID', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_NanCh', 'BD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SCSO_NanCh', 'GD', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SiChuan', 'AD', '3', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SiChuan', 'BD', '7', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SiChuan', 'GD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SiChuan', 'ID', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'SiChuan', 'SiChuan', 'RP_BRD', '2', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TianJin', 'BD', '25', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TianJin', 'GD', '17', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TianJin', 'ID', '22', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TianJin', 'PR', '0', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TianJin', 'RP_BRD', '5', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TJSB_ShiJZ', 'AD', '1', '201910');

insert into E_BDS_HRM_EMPLOYEEDEGREE 
values ('30', 'TianJin', 'TJSB_ShiJZ', 'ID', '0', '201910');

COMMIT;