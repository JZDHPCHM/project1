DELETE FROM E_BDS_HRM_MANAGESTATE WHERE DATA_DATE = '201911';
COMMIT;

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JSSO_XuZ', 'GMO', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'AD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'BD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LiaoNing', 'GMO', '2', '1', '0', '1', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_AnSh', 'GMO', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'IDSD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_DanDo', 'T4_DongGaS', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_FuSh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_JinZh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_ShenY', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSB_YingK', 'T4_BaYuQuS', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_AnSh', 'GMO', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_BenXi', 'IDSD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_LiaoY', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'LiaoNing', 'LNSO_TieL', 'IDSD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'QingDao', 'QingDao', 'BD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'QingDao', 'QingDao', 'GD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'QingDao', 'QingDao', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'QingDao', 'QingDao', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_DeZh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_JiNan', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_TaiAn', 'T4_FeiChen', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'GMO', '1', '1', '0', '1', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSB_WeiH', 'T4_WenDeng', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_JiN', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'GMO', '1', '0', '0', '1', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'IDSD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'IDT', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_LinYi', 'T4_CangSha', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_YanT', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_ZaoZh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'T4_ZhouCun', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'SDSO_ZiBo', 'T4_ZiChuan', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'ShanDong', 'AD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'ShanDong', 'GMO', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'ShanDong', 'ShanDong', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'GDSB_LeS', 'T4_QianWei', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SC_ChengD', 'T4_JinJiag', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSB_MeiSh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSB_NanCh', 'T4_XiChong', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSB_ZiGon', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SCSO_DaZho', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SiChuan', 'BD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SiChuan', 'GD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SiChuan', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'SiChuan', 'SiChuan', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'TianJin', 'TianJin', 'BD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'TianJin', 'TianJin', 'GD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'TianJin', 'TianJin', 'GMO', '2', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('30', 'QingDao', 'QingDao', 'GD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'BeiJing', 'BeiJing', 'AD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'BeiJing', 'BeiJing', 'BD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'BeiJing', 'BeiJing', 'GMO', '3', '3', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'DaLian', 'DaLian', 'BD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'DaLian', 'DaLian', 'GMO', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'DaLian', 'DaLian', 'T4_JinZhou', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GD_GuangZ', 'GMO', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GDSB_FOS', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GDSB_JMen', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GDSB_ZhaoQ', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GuangDong', 'AD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GuangDong', 'BD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'GuangDong', 'GuangDong', 'GMO', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HeNan', 'BD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HeNan', 'GA', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HeNan', 'GD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HeNan', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HN_ZhengZ', 'T4_GongYiZ', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSB_JiaoZ', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSB_KaiF', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSO_LuoH', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSO_LuoY', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSO_PuY', 'T4_NanLe', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HeNan', 'HNSO_SanMX', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'ACT_SD', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'BAO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'EMT', '11', '11', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'IA', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'IDT', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'HO', 'HO', 'LEG_COM', '2', '2', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JiangSu', 'AD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JiangSu', 'GD', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JiangSu', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JS_YanCheg', 'ID', '0', '0', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JSSO_NanJ', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JSSO_NanT', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'GMO', '1', '1', '0', '0', '201911');

insert into E_BDS_HRM_MANAGESTATE 
values ('17', 'JiangSu', 'JSSO_SuZ', 'ID', '0', '0', '0', '0', '201911');

COMMIT;