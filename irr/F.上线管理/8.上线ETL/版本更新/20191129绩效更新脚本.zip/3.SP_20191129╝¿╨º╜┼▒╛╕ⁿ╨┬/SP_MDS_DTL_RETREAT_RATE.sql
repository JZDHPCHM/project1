DROP PROCEDURE SP_MDS_DTL_RETREAT_RATE
/
CREATE PROCEDURE SP_MDS_DTL_RETREAT_RATE(V_INDATE  IN VARCHAR2,
                                  V_RTNCODE OUT VARCHAR2,
                                  V_RTNMSG  OUT VARCHAR2) AS
  /**********************************************************************/
  /* PROCEDURE NAME : SP_MDS_DTL_RETREAT_RATE  �˳�����                 */
  /* DEVELOPED BY   : WH                                                */
  /* DEVELOPED DATE : 2018-11-28                                        */
  /************************ SOUCE TABLE *********************************/
  /* TARGET TABLE   : E_MDS_RETREAT_RATE                                */
  /********************** VARIABLE SECTION ******************************/
  V_EVAL_STARTTIME VARCHAR2(10); --�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(10); --�����ڽ���ʱ��
  V_START          DATE; --ִ�п�ʼʱ��
  V_END            DATE; --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER; --��¼����
  V_SQL            VARCHAR2(30000); --��̬���
  /***********************************************************************/
BEGIN
DBMS_OUTPUT.ENABLE(1000000);
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE), 'YYYYMMDD') + 1,
                                         -3),
                              'YYYYMMDD');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE);
  --���������
  V_SQL:='TRUNCATE TABLE E_MDS_RETREAT_RATE';
  EXECUTE IMMEDIATE V_SQL;
  
  --����������������
  V_START := SYSDATE;
  V_SQL:= 'INSERT INTO E_MDS_RETREAT_RATE
(UUID	
,BRANCH_COM	
,CHANNEL	
,RETREAT_AMT	
,REVOKE_AMT	
,RECEIPTS_AMT	
,RECEIVABLE_AMT	
,RESULT_RATE
)	
select
 sys_guid()
,provincecomcode
,CHANNEL
,sum(RETREAT_AMT)  
,sum(REVOKE_AMT)  
,sum(RECEIPTS_AMT)  
,sum(RECEIVABLE_AMT)  
,ROUND(DECODE(sum(RECEIPTS_AMT)+sum(RECEIVABLE_AMT),0,0,(sum(RETREAT_AMT)+sum(REVOKE_AMT))/(sum(RECEIPTS_AMT)+sum(RECEIVABLE_AMT))),4)
from 
(SELECT 
   a.provincecomcode
  ,a.CHANNEL
  ,MAX(a.RETREAT_AMT) RETREAT_AMT
  ,MAX(a.REVOKE_AMT) REVOKE_AMT
  ,MAX(a.RECEIPTS_AMT) RECEIPTS_AMT
  ,MAX(a.RECEIVABLE_AMT) RECEIVABLE_AMT

FROM
(
--�˱���
SELECT 
           provincecomcode,
           DECODE(CHANNEL_CODE,''GB'',''GP'',''PP'',''GP'',''10'',''FC'',''20'',''BK'',''30'',''GP'',''40'',''AD'',''60'',''RP'',CHANNEL_CODE) AS CHANNEL,   
           SUM(FIN_AMT) RETREAT_AMT,
           0 REVOKE_AMT,
           0 RECEIPTS_AMT,
           0 RECEIVABLE_AMT
FROM E_BDS_FIN_GL
LEFT JOIN E_BDS_BIDM_MGECMP b
ON SUBSTR( org_no,2,2)=SUBSTR(provincecomcode,3,2)
WHERE  ITEM_CODE_LVL1=''4411''
AND   replace(GL_DATE,''-'','''')   BETWEEN ''' || V_EVAL_STARTTIME ||
             ''' AND ''' || V_EVAL_ENDTIME ||
             '''GROUP BY provincecomcode,CHANNEL_CODE
UNION ALL
--������
SELECT 
           M.PROVINCECOMCODE,
           DECODE(T.ADD_CHNLCOD,''GB'',''GP'',''PP'',''GP'',''10'',''FC'',''20'',''BK'',''30'',''GP'',''40'',''AD'',''60'',''RP'',T.ADD_CHNLCOD) AS CHANNEL,
           0,
           SUM(T.AMOUNT) * (-1),
           0,
           0
      FROM E_BDS_BIDM_LA_F_BUSINESS T, E_BDS_BIDM_MGECMP M
     WHERE T.TRANSTYP = ''P004''
       AND T.EDORTYPECODE = ''T646''
       AND T.INNERORGCODE = M.LAORIGORGCODE
       AND T.STATDATE BETWEEN ''' || V_EVAL_STARTTIME ||
             ''' AND ''' || V_EVAL_ENDTIME ||
             '''GROUP BY M.PROVINCECOMCODE,T.ADD_CHNLCOD
union all
--ʵ��
SELECT 
           provincecomcode,
           DECODE(CHANNEL_CODE,''GB'',''GP'',''PP'',''GP'',''10'',''FC'',''20'',''BK'',''30'',''GP'',''40'',''AD'',''60'',''RP'',CHANNEL_CODE) AS CHANNEL,
           0,
           0,
           SUM(FIN_AMT)* (-1),
           0
FROM E_BDS_FIN_GL
LEFT JOIN E_BDS_BIDM_MGECMP b
ON SUBSTR( org_no,2,2)=SUBSTR(provincecomcode,3,2)
WHERE  ITEM_CODE_LVL1=''4101''
AND   replace(GL_DATE,''-'','''')   BETWEEN ''' || V_EVAL_STARTTIME ||
             ''' AND ''' || V_EVAL_ENDTIME ||
             '''GROUP BY provincecomcode,CHANNEL_CODE
union all
--Ԥ��
SELECT  
           M.PROVINCECOMCODE,
           DECODE(T.ADD_CHNLCOD,''GB'',''GP'',''PP'',''GP'',''10'',''FC'',''20'',''BK'',''30'',''GP'',''40'',''AD'',''60'',''RP'',T.ADD_CHNLCOD) AS CHANNEL,
           0,
           0,
           0,
           SUM(T.AMOUNT) 
  FROM E_BDS_BIDM_LA_F_BUSINESS T, E_BDS_BIDM_MGECMP M
 WHERE T.TRANSTYP = ''P001''
   AND T.INNERORGCODE = M.LAORIGORGCODE
   AND T.STATDATE BETWEEN ''' || V_EVAL_STARTTIME || ''' AND ''' ||
           V_EVAL_ENDTIME || '''GROUP BY M.PROVINCECOMCODE,T.ADD_CHNLCOD
) a group by a.provincecomcode
  ,a.CHANNEL ) a
group by PROVINCECOMCODE,CHANNEL
 ';
 DBMS_OUTPUT.PUT_LINE(V_SQL);
  EXECUTE IMMEDIATE V_SQL;
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  V_END        := SYSDATE;
  /**************************************** ��ʼ������־��Ϣ ****************************************/
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     '',
     'SP_MDS_DTL_RETREAT_RATE',
     'E_MDS_RETREAT_RATE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  /**************************************** ������־��Ϣ��� ****************************************/
  /******************************************** �쳣���� ********************************************/
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      V_RTNCODE := '1';
      V_RTNMSG  := SQLERRM;
      V_END     := SYSDATE;
      /**************************************** ��ʼ������־��Ϣ ****************************************/
      INSERT INTO ETL_LOG_DETAIL
        (ID,
         INDEX_ID,
         SP_NAME,
         TABLE_NAME,
         START_TIME,
         END_TIME,
         DATA_DATE,
         RECORD_NUM,
         ERR_CODE,
         ERR_MSG)
      VALUES
        (SYS_GUID(),
         '',
         'SP_MDS_DTL_RETREAT_RATE',
         'E_MDS_RETREAT_RATE',
         V_START,
         V_END,
         V_INDATE,
         V_RECORD_NUM,
         V_RTNCODE,
         V_RTNMSG);
      COMMIT;
      /**************************************** ������־��Ϣ��� ****************************************/
    END;
END SP_MDS_DTL_RETREAT_RATE;

/
