DROP PROCEDURE SP_ADS_CONT_CHARGE_RATE
/
CREATE PROCEDURE SP_ADS_CONT_CHARGE_RATE(V_INDATE IN VARCHAR2,
                                                       V_RTNCODE OUT VARCHAR2,
                                                       V_RTNMSG  OUT VARCHAR2) AS

  /**********************************************************************/
  /* Procedure Name : SP_ADS_CONT_CHARGE_RATE  �����շ�                 */
  /* Developed By   : WH                                                */
  /* Developed Date : 2019-04-13                                        */
  /************************ Souce table *********************************/
  /* Target table   : E_ADS_CONTINUE_CHARGE_RATE                        */
  /* Source table   : E_MDS_CONTINUE_CHARGE_RATE                        */
  /********************** Variable Section ******************************/
  V_EVAL_STARTTIME VARCHAR2(10);    --�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(10);    --�����ڽ���ʱ��
  V_START          DATE;            --ִ�п�ʼʱ��
  V_END            DATE;            --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER;          --��¼����
  V_SQL            VARCHAR2(20000); --��̬���
  /***********************************************************************/
BEGIN
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE),
                                                 'yyyymmdd') + 1,-3),'yyyymmdd');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE);
  --------------------------------ɾ������-------------------------------
  V_SQL :='TRUNCATE TABLE E_ADS_CONTINUE_CHARGE_RATE';
  EXECUTE IMMEDIATE V_SQL;
  --------------------------------��������--------------------------------
  V_START := SYSDATE;
  V_SQL := 'INSERT INTO E_ADS_CONTINUE_CHARGE_RATE(
 uuid           
,month         
,sec_org       
,channel       
,receipts_amt  
,receivable_amt
,result_rate   
,score 
 )
SELECT
 uuid           
,month         
,sec_org       
,channel       
,receipts_amt  
,receivable_amt
,CASE WHEN result_rate IS NULL THEN NULL 
      WHEN result_rate = 0 THEN NULL  ELSE result_rate*100||''%'' END  
,CASE WHEN result_rate IS NULL THEN NULL
      WHEN result_rate = 0 THEN NULL
      WHEN result_rate>0.9 then 3
      when result_rate>0.8 then 1.5 else 0 end score
FROM E_MDS_CONTINUE_CHARGE_RATE';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     '',
     'SP_ADS_CONT_CHARGE_RATE',
     'E_ADS_CONTINUE_CHARGE_RATE',
     V_START,
     V_END,
     to_char(SYSDATE,'yyyymmdd'),
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------------�쳣����-----------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        ROLLBACK;
        V_END     := SYSDATE;
        V_RTNCODE := '1';
        V_RTNMSG  := SQLERRM;
  -----------------------------------������־��Ϣ������--------------------------------
      INSERT INTO ETL_LOG_DETAIL
        (ID,
         INDEX_ID,
         SP_NAME,
         TABLE_NAME,
         START_TIME,
         END_TIME,
         DATA_DATE,
         RECORD_NUM,
         ERR_CODE,
         ERR_MSG)
      VALUES
        (SYS_GUID(),
         '',
         'SP_ADS_CONT_CHARGE_RATE',
         'E_ADS_CONTINUE_CHARGE_RATE',
         V_START,
         V_END,
         to_char(SYSDATE,'yyyymmdd'),
         V_RECORD_NUM,
         V_RTNCODE,
         V_RTNMSG);
      COMMIT;
   -----------------------------------������־��Ϣ���--------------------------------
      END;
END SP_ADS_CONT_CHARGE_RATE;

/
