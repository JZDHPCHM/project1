DROP PROCEDURE SP_MDS_DTL_CONT_VISIT_RATE
/
CREATE PROCEDURE SP_MDS_DTL_CONT_VISIT_RATE(V_INDATE  IN  VARCHAR2,
                                                       V_RTNCODE OUT VARCHAR2,
                                                       V_RTNMSG  OUT VARCHAR2) AS

  /**********************************************************************/
  /* Procedure Name : SP_MDS_DTL_CONT_VISIT_RATE  ����Լ�ط�            */
  /* Developed By   : SY                                                */
  /* Developed Date : 2018-11-28                                        */
  /************************ Souce table *********************************/
  /* Target table   : E_MDS_CONTRACT_VISIT_RATE                         */
  /********************** Variable Section ******************************/
  V_EVAL_STARTTIME VARCHAR2(10); --�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(10); --�����ڽ���ʱ��
  V_START          DATE; --ִ�п�ʼʱ��
  V_END            DATE; --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER; --��¼����
  V_SQL            VARCHAR2(20000); --��̬���
  /***********************************************************************/
BEGIN
  DBMS_OUTPUT.ENABLE(1000000);
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE),
                                                 'yyyymmdd') + 1,-3),'yyyymmdd');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE);
  --------------------------------ɾ������-------------------------------
  V_SQL := 'TRUNCATE TABLE E_MDS_CONTRACT_VISIT_RATE';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  V_START := SYSDATE;
  V_SQL := 'INSERT INTO E_MDS_CONTRACT_VISIT_RATE(
             UUID,
             CHANNEL,
             ORG_NAME,
             VISIT_NUM,
             POLICY_NUM,
             RESULT_RATE)
SELECT SYS_GUID(),
       CHANNEL,
       PROVINCECOMCODE,
       NVL(SUM(C_CNT),0),
       SUM(S_CNT),
       CASE WHEN SUM(C_CNT) IS NULL THEN 0 
            WHEN SUM(C_CNT) = 0 THEN 0 
            WHEN SUM(S_CNT) IS NULL THEN NULL ELSE ROUND((SUM(C_CNT) / SUM(S_CNT)), 2) END 
  FROM (SELECT PROVINCECOMCODE, CHANNEL, COUNT(NVL(CHDRNUM, 0)) AS C_CNT, NULL AS S_CNT
  FROM (SELECT BASE.COMPANYNO || BASE.BRANCH CHDRCOY,
               DECODE(BASE.CHANNEL,''GB'',''GP'',''PP'',''GP'',BASE.CHANNEL) AS CHANNEL,
               BASE.ENDHESDATE,
               A.CHDRCOYID, --������
               A.CHDRNUM, --������
               A.CODE, --��Ʒ����
               A.OCCDATE, --������Ч��
               A.HOISSDTE, --����ǩ����
               A.AGTYPE, --����
               A.STATUS, --����״̬
               A.BACRS, --�طý��
               A.VSLSTATUS, --�׷���״̬
               A.VSLRESULT, --�׷��Żطý��
               A.ZACKDTE, --��ִǩ����
               A.CBLSTATUS, --�ط���״̬
               B.PROVINCECOMCODE
          FROM E_BDS_CCCMP_POLICYS_BASE BASE
          LEFT JOIN E_BDS_CCNT_CRM_CASE3 A
            ON A.CHDRCOYID = BASE.COMPANYNO || BASE.BRANCH
           AND A.CHDRNUM = BASE.CHDRNUM
         INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
            ON BASE.POLICYNO = INDI.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
            ON BASE.POLICYNO = CASE3.POLICYNO
          LEFT JOIN E_BDS_BIDM_MGECMP B
            ON B.LAORIGORGCODE = BASE.COMPANYNO
         WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN 
               to_date('''||V_EVAL_STARTTIME||''',''yyyy-mm-dd'') AND
               to_date('''||V_EVAL_ENDTIME||''',''yyyy-mm-dd'')
           AND INDI.ISCFI = ''0''
           AND INDI.ISWD = ''0''
           AND BASE.ZACKDTE IS NOT NULL
           AND BASE.ZACKDTE != ''99999999''
           AND BASE.NEEDCALLBACK = ''1''
           AND BASE.CNTTYPE NOT LIKE ''PA%''
           AND CASE3.BACRS NOT IN (''1'', ''10'')
           AND NOT
                (CASE3.DATIME LIKE ''% 0 :00AM'' OR CASE3.DATIME LIKE ''%000000'')
           AND BASE.CHANNEL IN (''FC'', ''BK'', ''AD'', ''RP'', ''GB'')) T
 WHERE BACRS IN (''2'', ''9'')
    OR VSLRESULT = ''0''
 GROUP BY PROVINCECOMCODE, CHANNEL
        UNION ALL
        SELECT B.PROVINCECOMCODE,
               DECODE(BASE.CHANNEL,''GB'',''GP'',''PP'',''GP'',BASE.CHANNEL) AS CHANNEL,
               NULL AS C_CNT,
               COUNT(NVL(BASE.POLICYNO, 0)) S_CNT
          FROM E_BDS_CCCMP_POLICYS_BASE BASE
         INNER JOIN E_BDS_CCCMP_POL_INDICATOR INDI
            ON BASE.POLICYNO = INDI.POLICYNO
         INNER JOIN E_BDS_CCCMP_CRM_CASE3 CASE3
            ON BASE.POLICYNO = CASE3.POLICYNO
          LEFT JOIN E_BDS_BIDM_MGECMP B
            ON B.LAORIGORGCODE = BASE.COMPANYNO
         WHERE TO_DATE(BASE.OCCDATE,''yyyy-mm-dd'') BETWEEN 
               to_date('''||V_EVAL_STARTTIME||''',''yyyy-mm-dd'') AND
               to_date('''||V_EVAL_ENDTIME||''',''yyyy-mm-dd'')
           AND INDI.ISCFI = ''0''
           AND INDI.ISWD = ''0''
           AND BASE.ZACKDTE IS NOT NULL
           AND BASE.ZACKDTE != ''99999999''
           AND BASE.NEEDCALLBACK = ''1''
           AND BASE.CNTTYPE NOT LIKE ''PA%''
           AND CASE3.BACRS NOT IN (''1'', ''10'')
           AND NOT
                (CASE3.DATIME LIKE ''% 0:00AM'' OR CASE3.DATIME LIKE ''%000000'')
         GROUP BY B.PROVINCECOMCODE, BASE.CHANNEL) C
 GROUP BY CHANNEL,PROVINCECOMCODE
 ORDER BY PROVINCECOMCODE,CHANNEL';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     '',
     'SP_MDS_DTL_CONT_VISIT_RATE',
     'E_MDS_CONTRACT_VISIT_RATE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------�쳣����-----------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        ROLLBACK;
        V_END     := SYSDATE;
        V_RTNCODE := '1';
        V_RTNMSG  := SQLERRM;
        INSERT INTO ETL_LOG_DETAIL
        (ID,
         INDEX_ID,
         SP_NAME,
         TABLE_NAME,
         START_TIME,
         END_TIME,
         DATA_DATE,
         RECORD_NUM,
         ERR_CODE,
         ERR_MSG)
      VALUES
        (SYS_GUID(),
         '',
         'SP_MDS_DTL_CONT_VISIT_RATE',
         'E_MDS_CONTRACT_VISIT_RATE',
         V_START,
         V_END,
         V_INDATE,
         V_RECORD_NUM,
         V_RTNCODE,
         V_RTNMSG);
      COMMIT;
   -----------------------------------������־��Ϣ���--------------------------------
      END;
END SP_MDS_DTL_CONT_VISIT_RATE;

/
