DROP PROCEDURE SP_MDS_DTL_CONT_CHARGE_RATE
/
CREATE PROCEDURE SP_MDS_DTL_CONT_CHARGE_RATE(V_INDATE  IN VARCHAR2,
                                  V_RTNCODE OUT VARCHAR2,
                                  V_RTNMSG  OUT VARCHAR2) AS
  /**********************************************************************/
  /* Procedure Name : SP_MDS_DTL_CONT_CHARGE_RATE  �����շ�             */
  /* Developed By   : WH                                                */
  /* Developed Date : 2018-11-28                                        */
  /************************ Souce table *********************************/
  /* Target table   : E_MDS_CONTINUE_CHARGE_RATE                        */
  /********************** Variable Section ******************************/
  V_EVAL_STARTTIME VARCHAR2(10);   	--�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(10);   --�����ڽ���ʱ��
  V_START          DATE;           --ִ�п�ʼʱ��
  V_END            DATE;           --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER;         --��¼����
  V_SQL            VARCHAR2(32767);--��̬���
  /***********************************************************************/
BEGIN
DBMS_OUTPUT.ENABLE(1000000);
  V_EVAL_STARTTIME := SUBSTR(TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE), 'yyyymmdd') + 1,
                                         -3),
                              'yyyymmdd'),1,6);
  V_EVAL_ENDTIME   := SUBSTR(FUN_ETL_Q_DATE(V_INDATE),1,6);
  --���������
  V_SQL :='TRUNCATE TABLE E_MDS_CONTINUE_CHARGE_RATE';
  EXECUTE IMMEDIATE V_SQL;
   
  --����������������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_CONTINUE_CHARGE_RATE
  (uuid
  ,month
  ,sec_org
  ,channel
  ,receipts_amt
  ,receivable_amt
  ,result_rate)
  select sys_guid(),
  FINMONTH,
  PROVINCECOMCODE,
  CHNLCOD, 
  sum(factvalue),
  sum(accountvalue),
  CASE WHEN sum(factvalue) IS NULL THEN 0 
       WHEN sum(factvalue) = 0 THEN 0
       WHEN sum(accountvalue) IS NULL THEN NULL ELSE 
       sum(factvalue)/sum(accountvalue) END
    from
  (
  --ʵ��
  select PROVINCECOMCODE,CHNLCOD,substr(FINMONTH,-1,1) FINMONTH,0 accountvalue,
  sum(MON13_REALPREM_MON_CUR)+sum(MON25_REALPREM_MON_CUR)+sum(MON37_REALPREM_MON_CUR)  factvalue
   from
  (
  SELECT
    Table__2.PROVINCECOMCODE PROVINCECOMCODE,
    E_BDS_BIDM_RENEWAL_RP_FY.FINMONTH,
     case when E_BDS_BIDM_RENEWAL_RP_FY.MON13_REALPREM_MON_CUR is null then 0
         else E_BDS_BIDM_RENEWAL_RP_FY.MON13_REALPREM_MON_CUR
    end MON13_REALPREM_MON_CUR,
    case when E_BDS_BIDM_RENEWAL_RP_FY.MON25_REALPREM_MON_CUR is null then 0
         else E_BDS_BIDM_RENEWAL_RP_FY.MON25_REALPREM_MON_CUR
    end MON25_REALPREM_MON_CUR,
    case when E_BDS_BIDM_RENEWAL_RP_FY.MON37_REALPREM_MON_CUR is null then 0
         else E_BDS_BIDM_RENEWAL_RP_FY.MON37_REALPREM_MON_CUR
    end MON37_REALPREM_MON_CUR,
    D_CHNL.CHNLCOD CHNLCOD
  FROM
    (
    select * from E_BDS_BIDM_MGECMP  a where a.innerorgcode !=''86''
    )  Table__2,
    (
    select s.FINMONTH,
         s.INNERORGCODE,
         s.ADD_CHNLCOD,
  /*       y.MON13_INSTPREM_MON_cur,*/
         y.MON13_REALPREM_MON_cur,
  /*       y.MON13_INSTPREM_cur,*/
         y.MON13_REALPREM_cur,
  /*       y.MON25_INSTPREM_MON_cur,*/
         y.MON25_REALPREM_MON_cur,
  /*       y.MON25_INSTPREM_cur,*/
         y.MON25_REALPREM_cur,
   /*      y.MON37_INSTPREM_MON_cur,*/
         y.MON37_REALPREM_MON_cur,
  /*       y.MON37_INSTPREM_cur,*/
         y.MON37_REALPREM_cur/*,
         y.MON13_INSTPREM_MON_last1,
         y.MON13_REALPREM_MON_last1,
         y.MON25_INSTPREM_MON_last1,
         y.MON25_REALPREM_MON_last1,
         y.MON37_INSTPREM_MON_last1,
         y.MON37_REALPREM_MON_last1,
         y.MON13_INSTPREM_MON_last2,
         y.MON13_REALPREM_MON_last2,
         y.MON25_INSTPREM_MON_last2,
         y.MON25_REALPREM_MON_last2,
         y.MON37_INSTPREM_MON_last2,
         y.MON37_REALPREM_MON_last2*/

    from (
          SELECT To_Char(FINMONTH) as FINMONTH,
                  E_BDS_BIDM_RENEWAL_RP_FY.innerorgcode as INNERORGCODE,
                  d_chnl.chnlcod AS ADD_CHNLCOD
            from E_BDS_BIDM_RENEWAL_RP_FY,
                 /* (select distinct innerorgcode from E_BDS_BIDM_RENEWAL_RP_FY) E_BDS_BIDM_MGECMP,*/
                  (select ''FC'' chnlcod
                     from dual
                   union all
                   select ''BK'' chnlcod
                     from dual
                   union all
                   select ''AD'' chnlcod from dual
                   union all
                   select ''RP'' chnlcod from dual) d_chnl
           group by To_Char(FINMONTH),
                     E_BDS_BIDM_RENEWAL_RP_FY.innerorgcode,
                     d_chnl.chnlcod) s,
         (select FINMONTH,

                 INNERORGCODE,
                 ADD_CHNLCOD,
                 /*sum(MON13_INSTPREM_MON_cur) as MON13_INSTPREM_MON_cur,*/
                 sum(MON13_REALPREM_MON_cur) as MON13_REALPREM_MON_cur,
                /* sum(MON13_INSTPREM_cur) as MON13_INSTPREM_cur,*/
                 sum(MON13_REALPREM_cur) as MON13_REALPREM_cur,
                -- sum(MON25_INSTPREM_MON_cur) as MON25_INSTPREM_MON_cur,
                 sum(MON25_REALPREM_MON_cur) as MON25_REALPREM_MON_cur,
                 -- sum(MON25_INSTPREM_cur) as MON25_INSTPREM_cur,
                 sum(MON25_REALPREM_cur) as MON25_REALPREM_cur,
                --  sum(MON37_INSTPREM_MON_cur) as MON37_INSTPREM_MON_cur,
                 sum(MON37_REALPREM_MON_cur) as MON37_REALPREM_MON_cur,
                --- sum(MON37_INSTPREM_cur) as MON37_INSTPREM_cur,
                 sum(MON37_REALPREM_cur) as MON37_REALPREM_cur/*,
                 sum(MON13_INSTPREM_MON_last1) as MON13_INSTPREM_MON_last1,
                 sum(MON13_REALPREM_MON_last1) as MON13_REALPREM_MON_last1,
                 sum(MON25_INSTPREM_MON_last1) as MON25_INSTPREM_MON_last1,
                 sum(MON25_REALPREM_MON_last1) as MON25_REALPREM_MON_last1,
                 sum(MON37_INSTPREM_MON_last1) as MON37_INSTPREM_MON_last1,
                 sum(MON37_REALPREM_MON_last1) as MON37_REALPREM_MON_last1,
                 sum(MON13_INSTPREM_MON_last2) as MON13_INSTPREM_MON_last2,
                 sum(MON13_REALPREM_MON_last2) as MON13_REALPREM_MON_last2,
                 sum(MON25_INSTPREM_MON_last2) as MON25_INSTPREM_MON_last2,
                 sum(MON25_REALPREM_MON_last2) as MON25_REALPREM_MON_last2,
                 sum(MON37_INSTPREM_MON_last2) as MON37_INSTPREM_MON_last2,
                 sum(MON37_REALPREM_MON_last2) as MON37_REALPREM_MON_last2*/
            from (SELECT To_Char(Add_Months(To_Date(FINMONTH, ''yyyymm''), +2),
                                 ''yyyymm'') as FINMONTH,
                         INNERORGCODE,
                         ADD_CHNLCOD,
                        -- MON13_INSTPREM_MON as MON13_INSTPREM_MON_cur,
                         MON13_REALPREM_MON as MON13_REALPREM_MON_cur,
                        -- MON13_INSTPREM as MON13_INSTPREM_cur,
                         MON13_REALPREM as MON13_REALPREM_cur,
                        -- MON25_INSTPREM_MON as MON25_INSTPREM_MON_cur,
                         MON25_REALPREM_MON as MON25_REALPREM_MON_cur,
                        -- MON25_INSTPREM as MON25_INSTPREM_cur,
                         MON25_REALPREM as MON25_REALPREM_cur,
                        -- MON37_INSTPREM_MON as MON37_INSTPREM_MON_cur,
                         MON37_REALPREM_MON as MON37_REALPREM_MON_cur,
                       --  MON37_INSTPREM as MON37_INSTPREM_cur,
                         MON37_REALPREM as MON37_REALPREM_cur/*,
                         0 MON13_INSTPREM_MON_last1,
                         0 MON13_REALPREM_MON_last1,
                         0 MON25_INSTPREM_MON_last1,
                         0 MON25_REALPREM_MON_last1,
                         0 MON37_INSTPREM_MON_last1,
                         0 MON37_REALPREM_MON_last1,
                         0 MON13_INSTPREM_MON_last2,
                         0 MON13_REALPREM_MON_last2,
                         0 MON25_INSTPREM_MON_last2,
                         0 MON25_REALPREM_MON_last2,
                         0 MON37_INSTPREM_MON_last2,
                         0 MON37_REALPREM_MON_last2*/

                    from E_BDS_BIDM_RENEWAL_RP_FY
                 ) t
           GROUP BY FINMONTH, INNERORGCODE, ADD_CHNLCOD) y
   where s.FINMONTH = y.FINMONTH(+)
     and s.INNERORGCODE = y.INNERORGCODE(+)
     and s.ADD_CHNLCOD = y.ADD_CHNLCOD(+)
    )  E_BDS_BIDM_RENEWAL_RP_FY,
    (
    select * from E_BDS_BIDM_CHNLCOD t where t.flg=''0'' and t.chnlcod<>''GR''
    )  D_CHNL,
    /*(
    select * from E_BDS_BIDM_MGECMP  a where a.innerorgcode !=''86''
    )  E_BDS_BIDM_MGECMP1,*/
    E_BDS_BIDM_MGECMP_MAP,
    (
    select * from E_BDS_BIDM_CHNL_MAP t
  where t.FLG=''0''
  and t.ADD_CHNLCOD<>''GR''
    )  E_BDS_BIDM_CHNL_MAP
  WHERE
    ( Table__2.INNERORGCODE=E_BDS_BIDM_MGECMP_MAP.BRANCHCOMCODE  )
    AND  ( E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE=Table__2.INNERORGCODE(+)  )
  /*  AND  ( E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE=E_BDS_BIDM_MGECMP1.INNERORGCODE(+)  )*/
    AND  ( D_CHNL.ADD_CHNLCOD=E_BDS_BIDM_RENEWAL_RP_FY.ADD_CHNLCOD  )
    AND  ( E_BDS_BIDM_CHNL_MAP.ADD_CHNLCOD=D_CHNL.ADD_CHNLCOD  )
    AND
    (
     E_BDS_BIDM_MGECMP_MAP.PROVINCECOMCODE  =  ''86''
     AND
     to_date(E_BDS_BIDM_RENEWAL_RP_FY.FINMONTH,''yyyymm'')  
     BETWEEN to_date(''' || V_EVAL_STARTTIME ||
               ''',''yyyymm'') 
     AND to_date(''' || V_EVAL_ENDTIME || ''',''yyyymm'')
     AND E_BDS_BIDM_CHNL_MAP.CHNLCOD  =  ''ALL'')
  )t
  GROUP BY PROVINCECOMCODE,CHNLCOD,substr(FINMONTH,-1,1)
  UNION ALL
  ----Ӧ��
  SELECT 
         PROVINCECOMCODE,
         CHNLCOD,
         substr(FINMONTH,-1,1) FINMONTH,
         SUM(MON13_INSTPREM_MON_CUR) + SUM(MON25_INSTPREM_MON_CUR) +
         SUM(MON37_INSTPREM_MON_CUR) ,
         0 
    FROM (SELECT TABLE__2.PROVINCECOMCODE PROVINCECOMCODE,
    E_BDS_BIDM_RENEWAL_RP_FY.FINMONTH,
                 CASE
                   WHEN E_BDS_BIDM_RENEWAL_RP_FY.MON13_INSTPREM_MON_CUR IS NULL THEN
                    0
                   ELSE
                    E_BDS_BIDM_RENEWAL_RP_FY.MON13_INSTPREM_MON_CUR
                 END MON13_INSTPREM_MON_CUR,
                 CASE
                   WHEN E_BDS_BIDM_RENEWAL_RP_FY.MON25_INSTPREM_MON_CUR IS NULL THEN
                    0
                   ELSE
                    E_BDS_BIDM_RENEWAL_RP_FY.MON25_INSTPREM_MON_CUR
                 END MON25_INSTPREM_MON_CUR,
                 CASE
                   WHEN E_BDS_BIDM_RENEWAL_RP_FY.MON37_INSTPREM_MON_CUR IS NULL THEN
                    0
                   ELSE
                    E_BDS_BIDM_RENEWAL_RP_FY.MON37_INSTPREM_MON_CUR
                 END MON37_INSTPREM_MON_CUR,
                 D_CHNL.CHNLCOD CHNLCOD
            FROM (SELECT *
                    FROM E_BDS_BIDM_MGECMP A
                   WHERE A.INNERORGCODE != ''86'') TABLE__2,
                 (
                 SELECT S.FINMONTH,
                         S.INNERORGCODE,
                         S.ADD_CHNLCOD,
                         Y.MON13_INSTPREM_MON_CUR,
                         /*   -- Y.MON13_REALPREM_MON_CUR,
                         Y.MON13_INSTPREM_CUR,*/
                         -- Y.MON13_REALPREM_CUR,
                         Y.MON25_INSTPREM_MON_CUR,
                         -- Y.MON25_REALPREM_MON_CUR,
                         /*                  Y.MON25_INSTPREM_CUR,*/
                         -- Y.MON25_REALPREM_CUR,
                         Y.MON37_INSTPREM_MON_CUR
                  -- Y.MON37_REALPREM_MON_CUR,
                  /*        Y.MON37_INSTPREM_CUR*/
                  --  Y.MON37_REALPREM_CUR,
                  --  Y.MON13_INSTPREM_MON_LAST1,
                  --  Y.MON13_REALPREM_MON_LAST1,
                  /*       -  Y.MON25_INSTPREM_MON_LAST1,
                  Y.MON25_REALPREM_MON_LAST1,
                  Y.MON37_INSTPREM_MON_LAST1,
                  Y.MON37_REALPREM_MON_LAST1,
                  Y.MON13_INSTPREM_MON_LAST2,
                  Y.MON13_REALPREM_MON_LAST2,
                  Y.MON25_INSTPREM_MON_LAST2,
                  Y.MON25_REALPREM_MON_LAST2,
                  Y.MON37_INSTPREM_MON_LAST2,
                  Y.MON37_REALPREM_MON_LAST2*/
                  
                    FROM (
                    SELECT TO_CHAR(FINMONTH) AS FINMONTH,
                                 E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE AS INNERORGCODE,
                                 D_CHNL.CHNLCOD AS ADD_CHNLCOD
                            FROM E_BDS_BIDM_RENEWAL_RP_FY,
                                 /*(SELECT DISTINCT INNERORGCODE
                                    FROM E_BDS_BIDM_RENEWAL_RP_FY) E_BDS_BIDM_MGECMP,*/
                                 (SELECT ''FC'' CHNLCOD
                                    FROM DUAL
                                  UNION ALL
                                  SELECT ''BK'' CHNLCOD
                                    FROM DUAL
                                  UNION ALL
                                  SELECT ''AD'' CHNLCOD
                                    FROM DUAL
                                  UNION ALL
                                  SELECT ''RP'' CHNLCOD
                                    FROM DUAL) D_CHNL
                           WHERE  /*E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE=E_BDS_BIDM_MGECMP.INNERORGCODE
                            AND*/ E_BDS_BIDM_RENEWAL_RP_FY.ADD_CHNLCOD=D_CHNL.CHNLCOD
                           GROUP BY TO_CHAR(FINMONTH),
                                    E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE,
                                    D_CHNL.CHNLCOD) S,
                         (SELECT FINMONTH,
                                 
                                 INNERORGCODE,
                                 ADD_CHNLCOD,
                                 SUM(MON13_INSTPREM_MON_CUR) AS MON13_INSTPREM_MON_CUR,
                                 --SUM(MON13_REALPREM_MON_CUR) AS MON13_REALPREM_MON_CUR,
                                 /*   SUM(MON13_INSTPREM_CUR) AS MON13_INSTPREM_CUR,
                                 --  SUM(MON13_REALPREM_CUR) AS MON13_REALPREM_CUR,*/
                                 SUM(MON25_INSTPREM_MON_CUR) AS MON25_INSTPREM_MON_CUR,
                                 /*               -- SUM(MON25_REALPREM_MON_CUR) AS MON25_REALPREM_MON_CUR,
                                 SUM(MON25_INSTPREM_CUR) AS MON25_INSTPREM_CUR,*/
                                 -- SUM(MON25_REALPREM_CUR) AS MON25_REALPREM_CUR,
                                 SUM(MON37_INSTPREM_MON_CUR) AS MON37_INSTPREM_MON_CUR
                          --  SUM(MON37_REALPREM_MON_CUR) AS MON37_REALPREM_MON_CUR,
                          /*  SUM(MON37_INSTPREM_CUR) AS MON37_INSTPREM_CUR*/
                          --   SUM(MON37_REALPREM_CUR) AS MON37_REALPREM_CUR,
                          /*  SUM(MON13_INSTPREM_MON_LAST1) AS MON13_INSTPREM_MON_LAST1,
                          SUM(MON13_REALPREM_MON_LAST1) AS MON13_REALPREM_MON_LAST1,
                          SUM(MON25_INSTPREM_MON_LAST1) AS MON25_INSTPREM_MON_LAST1,
                          SUM(MON25_REALPREM_MON_LAST1) AS MON25_REALPREM_MON_LAST1,
                          SUM(MON37_INSTPREM_MON_LAST1) AS MON37_INSTPREM_MON_LAST1,
                          SUM(MON37_REALPREM_MON_LAST1) AS MON37_REALPREM_MON_LAST1,
                          SUM(MON13_INSTPREM_MON_LAST2) AS MON13_INSTPREM_MON_LAST2,
                          SUM(MON13_REALPREM_MON_LAST2) AS MON13_REALPREM_MON_LAST2,
                          SUM(MON25_INSTPREM_MON_LAST2) AS MON25_INSTPREM_MON_LAST2,
                          SUM(MON25_REALPREM_MON_LAST2) AS MON25_REALPREM_MON_LAST2,
                          SUM(MON37_INSTPREM_MON_LAST2) AS MON37_INSTPREM_MON_LAST2,
                          SUM(MON37_REALPREM_MON_LAST2) AS MON37_REALPREM_MON_LAST2*/
                            FROM (SELECT TO_CHAR(ADD_MONTHS(TO_DATE(FINMONTH,
                                                                    ''yyyymm''),
                                                            +2),
                                                 ''yyyymm'') AS FINMONTH,
                                         INNERORGCODE,
                                         ADD_CHNLCOD,
                                         MON13_INSTPREM_MON AS MON13_INSTPREM_MON_CUR,
                                         -- MON13_REALPREM_MON AS MON13_REALPREM_MON_CUR,
                                         /*    MON13_INSTPREM AS MON13_INSTPREM_CUR,*/
                                         --  MON13_REALPREM AS MON13_REALPREM_CUR,
                                         MON25_INSTPREM_MON AS MON25_INSTPREM_MON_CUR,
                                         -- MON25_REALPREM_MON AS MON25_REALPREM_MON_CUR,
                                         /*    MON25_INSTPREM AS MON25_INSTPREM_CUR,*/
                                         -- MON25_REALPREM AS MON25_REALPREM_CUR,
                                         MON37_INSTPREM_MON AS MON37_INSTPREM_MON_CUR
                                  --  MON37_REALPREM_MON AS MON37_REALPREM_MON_CUR,
                                  /*       MON37_INSTPREM AS MON37_INSTPREM_CUR*/
                                  --   MON37_REALPREM AS MON37_REALPREM_CUR
                                  /* 0 MON13_INSTPREM_MON_LAST1,
                                  0 MON13_REALPREM_MON_LAST1,
                                  0 MON25_INSTPREM_MON_LAST1,
                                  0 MON25_REALPREM_MON_LAST1,
                                  0 MON37_INSTPREM_MON_LAST1,
                                  0 MON37_REALPREM_MON_LAST1,
                                  0 MON13_INSTPREM_MON_LAST2,
                                  0 MON13_REALPREM_MON_LAST2,
                                  0 MON25_INSTPREM_MON_LAST2,
                                  0 MON25_REALPREM_MON_LAST2,
                                  0 MON37_INSTPREM_MON_LAST2,
                                  0 MON37_REALPREM_MON_LAST2*/
                                  
                                    FROM E_BDS_BIDM_RENEWAL_RP_FY) T
                           GROUP BY FINMONTH, INNERORGCODE, ADD_CHNLCOD) Y
                   WHERE S.FINMONTH = Y.FINMONTH(+)
                     AND S.INNERORGCODE = Y.INNERORGCODE(+)
                     AND S.ADD_CHNLCOD = Y.ADD_CHNLCOD(+)) E_BDS_BIDM_RENEWAL_RP_FY,
                 (SELECT CHNLCOD,ADD_CHNLCOD
                    FROM E_BDS_BIDM_CHNLCOD T
                   WHERE T.FLG = ''0''
                     AND T.CHNLCOD <> ''GR'') D_CHNL,
                 /*(SELECT *
                  FROM E_BDS_BIDM_MGECMP A
                 WHERE A.INNERORGCODE != ''86'') E_BDS_BIDM_MGECMP1,*/
                 E_BDS_BIDM_MGECMP_MAP,
                 (SELECT ADD_CHNLCOD,CHNLCOD
                    FROM E_BDS_BIDM_CHNL_MAP T
                   WHERE T.FLG = ''0''
                     AND T.ADD_CHNLCOD <> ''GR'') E_BDS_BIDM_CHNL_MAP
           WHERE (TABLE__2.INNERORGCODE = E_BDS_BIDM_MGECMP_MAP.BRANCHCOMCODE)
             AND (E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE =
                 TABLE__2.INNERORGCODE(+))
                /* AND (E_BDS_BIDM_RENEWAL_RP_FY.INNERORGCODE =
                E_BDS_BIDM_MGECMP1.INNERORGCODE(+))*/
             AND (D_CHNL.ADD_CHNLCOD = E_BDS_BIDM_RENEWAL_RP_FY.ADD_CHNLCOD)
             AND (E_BDS_BIDM_CHNL_MAP.ADD_CHNLCOD = D_CHNL.ADD_CHNLCOD)
             AND (E_BDS_BIDM_MGECMP_MAP.PROVINCECOMCODE = ''86'' AND
                 TO_DATE(E_BDS_BIDM_RENEWAL_RP_FY.FINMONTH, ''yyyymm'')BETWEEN to_date(''' ||
               V_EVAL_STARTTIME || ''',''yyyymm'') 
     AND to_date(''' || V_EVAL_ENDTIME ||
               ''',''yyyymm'')
     AND
     E_BDS_BIDM_CHNL_MAP.CHNLCOD  =  ''ALL''
    )
  )t
  group by PROVINCECOMCODE,CHNLCOD,substr(FINMONTH,-1,1) 
  ) b
  group by FINMONTH,PROVINCECOMCODE,CHNLCOD
  order by FINMONTH,PROVINCECOMCODE
   ';
      dbms_output.put_line(V_SQL);
  EXECUTE IMMEDIATE V_SQL;
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  V_END        := SYSDATE;
  /**************************************** ��ʼ������־��Ϣ ****************************************/
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     '',
     'SP_MDS_DTL_CONT_CHARGE_RATE',
     'E_MDS_CONTINUE_CHARGE_RATE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  /**************************************** ������־��Ϣ��� ****************************************/
  
/******************************************** �쳣���� ********************************************/
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      V_RTNCODE := '1';
      V_RTNMSG  := SQLERRM;
      V_END     := SYSDATE;
  /**************************************** ��ʼ������־��Ϣ ****************************************/
      INSERT INTO ETL_LOG_DETAIL
        (ID,
         INDEX_ID,
         SP_NAME,
         TABLE_NAME,
         START_TIME,
         END_TIME,
         DATA_DATE,
         RECORD_NUM,
         ERR_CODE,
         ERR_MSG)
      VALUES
        (SYS_GUID(),
         '',
         'SP_MDS_DTL_CONT_CHARGE_RATE',
         'E_MDS_CONTINUE_CHARGE_RATE',
         V_START,
         V_END,
         V_INDATE,
         V_RECORD_NUM,
         V_RTNCODE,
         V_RTNMSG);
      COMMIT;
      /**************************************** ������־��Ϣ��� ****************************************/
    END;
END SP_MDS_DTL_CONT_CHARGE_RATE;

/
