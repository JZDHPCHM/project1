DELETE FROM E_ADS_IRR_INDEX_VALUE 
WHERE  EVAL_DATE='2019Q3' 
AND INDEX_ID='OR04020'
AND TO_CHAR(LOAD_DT,'YYYYMMDD') = 20191015;
COMMIT;


insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8601', 'AD', 226.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8601', 'BK', 8.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8601', 'FC', 401.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8601', 'RP', 14.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8601', '', 649.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8602', 'BK', 355.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8602', 'FC', 1802.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8602', 'GP', 7.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8602', 'RP', 29.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8602', '', 2193.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8603', 'AD', 69.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8603', 'FC', 605.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8603', 'RP', 12.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8603', '', 686.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', 'AD', 1005.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', 'BK', 488.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', 'FC', 1973.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', 'GP', 12.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', 'RP', 73.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8604', '', 3551.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8605', 'AD', 755.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8605', 'FC', 3626.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8605', 'GP', 9.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8605', 'RP', 68.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8605', '', 4458.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8606', 'AD', 495.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8606', 'FC', 2545.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8606', 'RP', 72.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8606', '', 3112.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', 'AD', 391.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', 'BK', 1.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', 'FC', 748.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', 'GP', 2.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', 'RP', 20.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8607', '', 1162.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8608', 'AD', 196.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8608', 'BK', 316.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8608', 'FC', 1611.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8608', 'RP', 47.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8608', '', 2170.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8609', 'BK', 366.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8609', 'FC', 357.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8609', 'RP', 8.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8609', '', 731.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8610', 'AD', 193.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8610', 'FC', 567.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8610', 'RP', 18.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8610', '', 778.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8611', 'AD', 190.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8611', 'FC', 1.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '8611', '', 191.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '', 'AD', 3520.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '', 'BK', 1534.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '', 'FC', 14236.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '', 'GP', 30.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04020', '', 'RP', 361.0000, '2019Q3', to_date('15-10-2019', 'dd-mm-yyyy'));

COMMIT;
