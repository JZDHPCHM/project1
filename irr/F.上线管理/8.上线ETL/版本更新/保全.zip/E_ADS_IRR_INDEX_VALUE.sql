DELETE FROM E_ADS_IRR_INDEX_VALUE T
WHERE T.EVAL_DATE = '2019Q2'
AND INDEX_ID IN ('OR06003',
'OR04025',
'OR04026',
'OR04027',
'OR04034')
AND TO_CHAR(LOAD_DT,'YYYYMMDD') = 20190715;
COMMIT;

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', 'AD', 93.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', 'AD', 2746.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', 'AD', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', 'AD', 400.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', 'AD', 790.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', 'AD', 914.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8607', 'AD', 134.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', 'AD', 206.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', 'AD', 105.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8611', 'AD', 31.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', 'AD', 2746.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8604', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8605', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8606', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', 'AD', 93.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', 'AD', 54.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', 'AD', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', 'AD', 401.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', 'AD', 789.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', 'AD', 913.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8607', 'AD', 134.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', 'AD', 208.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', 'AD', 104.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8611', 'AD', 32.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', 'AD', 2747.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', 'AD', 93.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', 'AD', 54.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', 'AD', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', 'AD', 400.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', 'AD', 790.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', 'AD', 914.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8607', 'AD', 134.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', 'AD', 206.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', 'AD', 105.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8611', 'AD', 31.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', 'AD', 54.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', 'BK', 237.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', 'BK', 2791.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', 'BK', 82.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', 'BK', 353.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', 'BK', 316.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', 'BK', 219.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8607', 'BK', 57.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', 'BK', 621.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', 'BK', 480.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8611', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', 'BK', 2791.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8602', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8608', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '', 'BK', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', 'BK', 237.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', 'BK', 394.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', 'BK', 82.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', 'BK', 353.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', 'BK', 316.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', 'BK', 219.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8607', 'BK', 57.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', 'BK', 621.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', 'BK', 480.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8611', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', 'BK', 2787.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', 'BK', 237.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', 'BK', 398.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', 'BK', 82.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', 'BK', 353.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', 'BK', 316.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', 'BK', 219.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8607', 'BK', 57.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', 'BK', 621.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', 'BK', 480.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8611', 'BK', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', 'BK', 398.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', 'FC', 425.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', 'FC', 2730.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', 'FC', 685.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', 'FC', 3126.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', 'FC', 2717.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', 'FC', 3124.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8607', 'FC', 1037.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', 'FC', 2321.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', 'FC', 687.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', 'FC', 662.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8611', 'FC', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', 'FC', 17528.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8602', 'FC', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8603', 'FC', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8604', 'FC', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8605', 'FC', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8606', 'FC', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8607', 'FC', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8608', 'FC', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8609', 'FC', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8610', 'FC', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '', 'FC', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', 'FC', 425.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', 'FC', 2730.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', 'FC', 682.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', 'FC', 3128.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', 'FC', 2725.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', 'FC', 3124.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8607', 'FC', 1037.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', 'FC', 2317.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', 'FC', 685.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', 'FC', 662.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8611', 'FC', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', 'FC', 17529.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', 'FC', 425.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', 'FC', 2730.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', 'FC', 685.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', 'FC', 3126.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', 'FC', 2717.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', 'FC', 3124.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8607', 'FC', 1037.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', 'FC', 2321.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', 'FC', 687.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', 'FC', 662.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8611', 'FC', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', 'FC', 17528.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', 'GP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', 'GP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', 'GP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', 'RP', 11.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8607', 'RP', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', 'RP', 89.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', 'RP', 88.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', 'RP', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8607', 'RP', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', 'RP', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', 'RP', 11.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', 'RP', 88.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8607', 'RP', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', 'RP', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', 'RP', 11.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', 'RP', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', '��', 36.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', '��', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', '��', 50.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', '��', 100.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '', '��', 222.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', '��', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', '��', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', '��', 36.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', '��', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', '��', 50.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', '��', 100.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '', '��', 222.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', '��', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', '��', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', '��', 36.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', '��', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', '��', 50.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', '��', 100.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '', '��', 222.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', '��', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', '��', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', '��', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8601', '', 762.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR06003', '86', '', 0.1600, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8603', '', 792.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8604', '', 3932.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8605', '', 3857.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8606', '', 4325.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8607', '', 1241.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8608', '', 3253.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8609', '', 1181.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8610', '', 802.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8611', '', 46.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '86', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8601', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8602', '', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8603', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8604', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8605', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8606', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8607', '', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8608', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8609', '', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8610', '', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '8611', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04026', '', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8601', '', 763.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8602', '', 3190.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8603', '', 789.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8604', '', 3935.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8605', '', 3864.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8606', '', 4324.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8607', '', 1241.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8608', '', 3251.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8609', '', 1179.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8610', '', 801.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04027', '8611', '', 47.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8601', '', 762.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8602', '', 3194.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8603', '', 792.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8604', '', 3932.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8605', '', 3857.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8606', '', 4325.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8607', '', 1241.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8608', '', 3253.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8609', '', 1181.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8610', '', 802.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04034', '8611', '', 46.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04025', '8602', '', 3194.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));
COMMIT;
