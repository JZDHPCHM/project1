DELETE FROM E_ADS_IRR_INDEX_VALUE  WHERE INDEX_ID IN ('OR02002',
'OR02003',
'OR02034',
'OR02004',
'OR02006',
'OR04002',
'OR04003',
'OR04005',
'OR04006',
'OR04007',
'OR04009',
'OR04010')
AND TO_CHAR(LOAD_DT,'YYYYMMDD') = 20190715;
COMMIT;

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'FC', 1441.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02002', '86', '', 1469.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'AD', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'BK', 116.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'FC', 5723.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'GP', 59.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', 'RP', 73.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02003', '86', '', 5997.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'FC', 5471.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', '', 5757.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02004', '86', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'AD', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'BK', 87.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'FC', 4006.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'GP', 53.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', 'RP', 78.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02006', '86', '', 4250.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', 'FC', 5471.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR02034', '86', '', 5757.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8601', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8602', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '', '', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8610', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8609', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8608', '', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8607', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8606', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8605', '', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8604', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04002', '8603', '', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8601', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8610', '', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8609', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8608', '', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8607', '', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '', '', 72.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8605', '', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8604', '', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8603', '', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8602', '', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04003', '8606', '', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'BK', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'FC', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', 'RP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8607', '', 23.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'BK', 36.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'CS', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'FC', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8608', '', 47.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'BK', 11.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'FC', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', 'RP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8609', '', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'BK', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'FC', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8610', '', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'AD', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'BK', 107.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'CS', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'FC', 78.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'GP', 33.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '', 'RP', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'CS', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'FC', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', 'RP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8601', '', 23.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'FC', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8602', '', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'FC', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8603', '', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'FC', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'GP', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8604', '', 53.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'BK', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'FC', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8605', '', 39.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'FC', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04005', '8606', '', 19.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'AD', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'BK', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'CS', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'FC', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'GP', 11.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8601', '', 43.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'AD', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'BK', 23.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'CS', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'FC', 37.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'GP', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', 'RP', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8602', '', 98.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'FC', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8603', '', 20.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'AD', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'CS', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'FC', 68.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'GP', 20.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8604', '', 146.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'BK', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'CS', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'FC', 43.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'GP', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', 'RP', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8605', '', 97.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'AD', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'CS', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'FC', 45.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8606', '', 82.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'AD', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'BK', 7.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'FC', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'GP', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', 'RP', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8607', '', 59.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'AD', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'BK', 56.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'CS', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'FC', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', 'RP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8608', '', 110.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'BK', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'FC', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8609', '', 32.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'FC', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '8610', '', 29.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'AD', 45.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'BK', 157.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'CS', 45.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'FC', 285.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'GP', 98.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04006', '', 'RP', 86.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', '', 55.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'BK', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'FC', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'GP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8609', '', 22.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'AD', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'FC', 13.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8610', '', 26.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'AD', 23.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'BK', 96.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'CS', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'FC', 143.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'GP', 36.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '', 'RP', 34.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'BK', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'FC', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8601', '', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'FC', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', 'RP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8602', '', 37.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'FC', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'GP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8603', '', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'AD', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'BK', 23.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'CS', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'FC', 32.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8604', '', 72.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'BK', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'FC', 19.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', 'RP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8605', '', 42.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'FC', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', 'RP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8606', '', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'BK', 12.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'CS', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'FC', 15.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'GP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8607', '', 35.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'BK', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'CS', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04007', '8608', 'FC', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'FC', 225.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', '', 229.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8611', 'FC', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8611', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'FC', 5471.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'FC', 103.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8601', '', 117.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'BK', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'FC', 749.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'GP', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', 'RP', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8602', '', 805.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'FC', 276.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8603', '', 283.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'FC', 815.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'GP', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8604', '', 872.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'FC', 877.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'GP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8605', '', 908.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'FC', 1152.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', 'RP', 15.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8606', '', 1173.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'FC', 426.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8607', '', 449.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'BK', 39.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'FC', 702.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', 'RP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8608', '', 756.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'FC', 143.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8609', '', 162.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04009', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'RP', 83.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'BK', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'FC', 103.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'GP', 4.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8601', '', 117.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'AD', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'BK', 25.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'FC', 749.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'GP', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', 'RP', 8.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8602', '', 805.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'FC', 276.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8603', '', 283.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'BK', 21.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'FC', 815.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'GP', 14.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', 'RP', 16.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8604', '', 872.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'BK', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'FC', 877.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'GP', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', 'RP', 17.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8605', '', 908.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'AD', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'FC', 1152.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', 'RP', 15.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8606', '', 1173.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'BK', 9.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'FC', 426.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'GP', 6.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', 'RP', 5.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8607', '', 449.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'AD', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'BK', 39.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'FC', 702.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'GP', 2.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', 'RP', 10.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8608', '', 756.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'BK', 18.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'FC', 143.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', 'RP', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8609', '', 162.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'AD', 1.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'BK', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'FC', 225.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'GP', 0.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', 'RP', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8610', '', 229.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8611', 'FC', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '8611', '', 3.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'AD', 27.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'BK', 118.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'FC', 5471.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR04010', '', 'GP', 58.0000, '2019Q2', to_date('15-07-2019', 'dd-mm-yyyy'));
COMMIT;
