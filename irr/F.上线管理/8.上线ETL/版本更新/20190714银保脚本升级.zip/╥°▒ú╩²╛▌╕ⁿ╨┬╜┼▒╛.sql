DELETE FROM E_ADS_IRR_INDEX_VALUE T 
WHERE T.EVAL_DATE = '2019Q2' 
AND TO_CHAR(T.LOAD_DT,'YYYYMMDD') = '20190714'
AND T.INDEX_ID IN ('OR13014','OR13015');
COMMIT;

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '86', 'BK', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '86', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '86', '', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8601', 'BK', 998.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8601', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8601', '', 998.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8602', 'BK', 1505.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8602', 'GP', 42.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8602', '', 1547.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8603', 'BK', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8603', 'GP', 1000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8603', '', 1000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8604', 'BK', 983.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8604', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8604', '', 983.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8605', 'BK', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8605', 'GP', 23.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8605', '', 23.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8606', 'BK', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8606', 'GP', 30.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8606', '', 30.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8607', 'BK', 173.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8607', 'GP', 13000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8607', '', 13173.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8608', 'BK', 1946.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8608', 'GP', 1.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8608', '', 1947.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8609', 'BK', 563.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8609', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8609', '', 563.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8610', 'BK', 760.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8610', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8610', '', 760.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8611', 'BK', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8611', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '8611', '', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '', 'BK', 6928.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13014', '', 'GP', 14096.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '86', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '86', '', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8601', 'BK', 998.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8601', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8601', '', 998.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8602', 'BK', 1505.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8602', 'GP', 42.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8602', '', 1547.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8603', 'GP', 1000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8603', '', 1000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8604', 'BK', 983.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8604', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8604', '', 983.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8605', 'GP', 23.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8605', '', 23.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8606', 'GP', 30.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8606', '', 30.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8607', 'BK', 173.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8607', 'GP', 13000.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8607', '', 13173.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8608', 'BK', 1946.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8608', 'GP', 1.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8608', '', 1947.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8609', 'BK', 563.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8609', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8609', '', 563.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8610', 'BK', 760.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8610', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8610', '', 760.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8611', 'GP', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '8611', '', 0.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '', 'BK', 6928.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

insert into E_ADS_IRR_INDEX_VALUE (INDEX_ID, ORG_ID, CHANNEL_ID, INDEX_VALUE, EVAL_DATE, LOAD_DT)
values ('OR13015', '', 'GP', 14096.0000, '2019Q2', to_date('14-07-2019', 'dd-mm-yyyy'));

COMMIT;