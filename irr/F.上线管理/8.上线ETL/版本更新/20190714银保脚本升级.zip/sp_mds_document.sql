DROP PROCEDURE SP_MDS_DOCUMENT
/

CREATE PROCEDURE SP_MDS_DOCUMENT(V_INDATE  IN  VARCHAR2,
                                        V_RTNCODE OUT VARCHAR2,
                                        V_RTNMSG  OUT VARCHAR2) AS
  /**********************************************************************/
  /* Procedure Name : SP_MDS_DOCUMENT                                   */
  /* Developed By   : SY                                                */
  /* Developed Date : 2018-10-31                                        */
  /* Modified  Date : 2019-01-21  WH             ������������           */
  /************************ Souce table *********************************/
  /* Target table   : E_MDS_IRR_INDEX_VALUE                             */
  /********************** Variable Section ******************************/
  V_EVAL_STARTTIME VARCHAR2(20); --�����ڿ�ʼʱ��
  V_EVAL_ENDTIME   VARCHAR2(20); --�����ڽ���ʱ��
  V_START          DATE; --ִ�п�ʼʱ��
  V_END            DATE; --ִ�н���ʱ��
  V_RECORD_NUM     NUMBER; --��¼����
  V_SQL            VARCHAR2(20000); --��̬���
  /***********************************************************************/
BEGIN
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE), 'yyyymmdd') + 1, -12),'yyyymmdd');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE);
  --------------------------------ɾ������-------------------------------
 DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = 'OR12003'
  AND CHANNEL_ID='GP' 
  AND TO_CHAR(LOAD_DT,'yyyymmdd') =  V_INDATE ;
  COMMIT;
  --------------------------------��������--------------------------------
  V_START := SYSDATE;
  
  /*--------------------------------------------------------------------------
  -----------------------------�����ղ���-------------------------------------
  --------------------------------------------------------------------------*/
  
  --���4�������ڿհ׵�֤���ŵ�����
  V_SQL := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
           SELECT ''OR12003'',
                  ''86'',
                  ''GP'',
                  NVL(SUM(A.SUMCOUNT),0),
                 CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
  FROM E_BDS_LISHASL_LZCARDTRACK A
  LEFT JOIN E_BDS_BIDM_MGECMP B
    ON A.MANAGECOM = B.INNERORGCODE
 WHERE OPERATEFLAG = ''4'' --����ȷ��
  AND RECEIVECOM LIKE ''B%'' --T3����
   AND TO_CHAR(A.MAKEDATE, ''YYYYMMDD'') 
   BETWEEN '''||V_EVAL_STARTTIME||''' 
   AND '''||V_EVAL_ENDTIME||'''';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
 INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR12003',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
   --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR12002''
  AND CHANNEL_ID=''GP'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѷ��ſհ׵�֤ȱʧ������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR12002'',
                 ''86'',
                 ''GP'',
                 NVL(COUNT(A.PRTNO),0),
               CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM E_BDS_LISHASL_LZCARDSTATE A
            LEFT JOIN E_BDS_BIDM_MGECMP B
            ON A.MANAGECOM = B.INNERORGCODE
            WHERE A.BACKSTATE = ''2''
            AND A.USESTATE= ''1''
            AND TO_CHAR(A.BACKDATE,''YYYYMMDD'') BETWEEN '''||V_EVAL_STARTTIME||''' 
                  AND '''||V_EVAL_ENDTIME||'''';            
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
   INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR12002',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������-------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE
   WHERE INDEX_ID = ''OR13012'' 
   AND CHANNEL_ID=''GP'' 
   AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  V_START := SYSDATE;
  --���4�������ڿհ׵�֤���ŵ�����
  V_SQL := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
 SELECT ''OR13012'',
                  B.PROVINCECOMCODE,
                  ''GP'',
                  NVL(SUM(A.SUMCOUNT),0),
                 CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
                  FROM E_BDS_LISHASL_LZCARDTRACK A
  RIGHT JOIN E_BDS_BIDM_MGECMP B
    ON A.MANAGECOM = B.INNERORGCODE
 AND OPERATEFLAG = ''4'' --����ȷ��
  AND RECEIVECOM LIKE ''B%'' --T3����
   AND( TO_CHAR(A.MAKEDATE, ''YYYYMMDD'') 
   BETWEEN '''||V_EVAL_STARTTIME||''' 
   AND '''||V_EVAL_ENDTIME||''')
   group by B.PROVINCECOMCODE
   ';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------��ʼ������־��Ϣ-------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
 INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13012',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13011''
  AND CHANNEL_ID=''GP'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѷ��ſհ׵�֤ȱʧ������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13011'',
                 B.PROVINCECOMCODE,
                 ''GP'',
                 NVL(COUNT(A.PRTNO),0),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM E_BDS_LISHASL_LZCARDSTATE A
            RIGHT JOIN E_BDS_BIDM_MGECMP B
            ON A.MANAGECOM = B.INNERORGCODE
            AND A.BACKSTATE = ''2''
            AND A.USESTATE= ''1''
            AND TO_CHAR(A.BACKDATE,''YYYYMMDD'') BETWEEN '''||V_EVAL_STARTTIME||''' 
                  AND '''||V_EVAL_ENDTIME||'''  
            GROUP BY B.PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
   INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13011',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13014''
  AND CHANNEL_ID=''GP'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѻ������м۵�֤����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13014'',
                 B.PROVINCECOMCODE,
                 ''GP'',
                 NVL(SUM(A.sumcount),0),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM ( select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom = z.receivecom
                         and z.operateflag = ''7''
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')
                      union all
                      select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom <> z.receivecom
                         and z.operateflag = ''1''
                         and z.payflag = ''1''
                          
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')
                      union all
                      select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom <> z.receivecom
                         and z.operateflag = ''5''
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')) A
            RIGHT JOIN E_BDS_BIDM_MGECMP B
            ON A.managecom = B.INNERORGCODE
            GROUP BY B.PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13014',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13015''
  AND CHANNEL_ID=''GP'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4�������ڰ���˾�涨ʱ����Ӧ�������м۵�֤����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13015'',
                 B.PROVINCECOMCODE,
                 ''GP'',
                 NVL(SUM(A.sumcount),0),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
            FROM ( select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom = z.receivecom
                         and z.operateflag = ''7''
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')
                      union all
                      select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom <> z.receivecom
                         and z.operateflag = ''1''
                         and z.payflag = ''1''
                          
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')
                      union all
                      select z.managecom AS managecom, z.sumcount AS sumcount
                        from E_BDS_LISHASL_LZCARDTRACK z
                       where z.sendoutcom <> z.receivecom
                         and z.operateflag = ''5''
                        AND( TO_CHAR(makedate, ''YYYYMMDD'') 
                         BETWEEN '''||V_EVAL_STARTTIME||''' 
                         AND '''||V_EVAL_ENDTIME||''')) A
            RIGHT JOIN E_BDS_BIDM_MGECMP B
            ON A.managecom = B.INNERORGCODE
            GROUP BY B.PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  --------------------------------������־��Ϣ���-----------------------------
  --------------------------------��ʼ������־��Ϣ-----------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13015',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  
  /*--------------------------------------------------------------------------
  -----------------------------��������---------------------------------------
  --------------------------------------------------------------------------*/
  
  V_EVAL_STARTTIME := TO_CHAR(ADD_MONTHS(TO_DATE(FUN_ETL_Q_DATE(V_INDATE), 'yyyymmddhh24miss') + 1, -12),'yyyymmddhh24miss');
  V_EVAL_ENDTIME   := FUN_ETL_Q_DATE(V_INDATE)||'235959';
   --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13012''
  AND CHANNEL_ID=''BK'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4�������ڿհ׵�֤���ŵ�����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13012'',
                 B.PROVINCECOMCODE,
                 ''BK'',
                 count(DISTINCT docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')    
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A 
 RIGHT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 AND STATUS IN (''2'',''4'')--2 T2���š� 4 T3����
 AND PFLAG_H=''1''
 AND to_date(updatetime,''yyyymmddhh24miss'')
 BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
 AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
 GROUP BY B.PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13012',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
 --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13011''
  AND CHANNEL_ID=''BK'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѷ��ſհ׵�֤ȱʧ������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
  SELECT ''OR13011'',
                 B.PROVINCECOMCODE,
                 ''BK'',
                 count(DISTINCT docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A
 RIGHT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 AND  STATUS=''9''     --��ʧ
   AND SUBSTR(team,1,1)=''4''
   AND TO_DATE(UPDATETIME, ''yyyymmddhh24miss'') 
   BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
   AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
   AND PFLAG_H =''1''
   AND docno IN (
 SELECT DOCNO  
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A 
 LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 WHERE STATUS IN (''2'',''4'')--2 T2���š� 4 T3����
 AND PFLAG_H=''1''
 AND to_date(updatetime,''yyyymmddhh24miss'')
 BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
 AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
 )
 GROUP BY B.PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
   INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13011',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT; 
--------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR13014''
  AND CHANNEL_ID=''BK'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѻ������м۵�֤����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13014'',
                PROVINCECOMCODE,
                 ''BK'',
                 COUNT(docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
FROM (SELECT * FROM (
SELECT ROW_NUMBER()OVER(PARTITION BY DOCNO ORDER BY UPDATETIME DESC) RN,docno,updatetime,pflag_h,team,status
FROM (SELECT * FROM(SELECT * FROM E_BDS_AFMS_AFMS_AFMS_HISTORY T WHERE DOCNO IN(
SELECT DOCNO FROM E_BDS_AFMS_AFMS_AFMS_HISTORY T WHERE T.STATUS IN (''2'',''4'')))
WHERE  STATUS IN (''6'',''8'',''9'',''12'',''11''))) T
WHERE rn= 1 
AND T.PFLAG_H=''1''
AND  to_date(updatetime,''yyyymmddhh24miss'')
BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')) a 
 RIGHT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 GROUP BY PROVINCECOMCODE
';
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13014',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE
   WHERE INDEX_ID = ''OR13015''
   AND CHANNEL_ID=''BK'' 
   AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4�������ڰ���˾�涨ʱ����Ӧ�������м۵�֤����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR13015'',
                 PROVINCECOMCODE,
                 ''BK'',
                 sum(docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')

from (
--�ѻ���
SELECT PROVINCECOMCODE,COUNT(docno) docno  
FROM (SELECT * FROM (
SELECT ROW_NUMBER()OVER(PARTITION BY DOCNO ORDER BY UPDATETIME DESC) RN,docno,updatetime,pflag_h,team,status
FROM (SELECT * FROM(SELECT * FROM E_BDS_AFMS_AFMS_AFMS_HISTORY T WHERE DOCNO IN(
SELECT DOCNO FROM E_BDS_AFMS_AFMS_AFMS_HISTORY T WHERE T.STATUS IN (''2'',''4'')))
WHERE  STATUS IN (''6'',''8'',''9'',''12'',''11''))) T
WHERE rn= 1 
AND T.PFLAG_H=''1''
AND  to_date(updatetime,''yyyymmddhh24miss'')
BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')) a 
 LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 GROUP BY PROVINCECOMCODE
UNION ALL
--����δ����
SELECT PROVINCECOMCODE,COUNT(DISTINCT docno)
  FROM (SELECT  DOCNO,PROVINCECOMCODE,LEAST(ADD_MONTHS(TO_DATE(UPDATETIME, ''yyyymmddhh24miss''), 12),
           to_date(DEADLINE,''yyyymmdd'')) AS ctime  ,to_date(DEADLINE,''yyyymmdd'') AS DEADLINE
                   FROM E_BDS_AFMS_AFMS_AFMS_HISTORY a 
                    LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
                  WHERE STATUS IN (''2'', ''4'') 
                  ) t
 WHERE CTIME > DEADLINE
 GROUP BY PROVINCECOMCODE) t       
 GROUP BY PROVINCECOMCODE';
  EXECUTE IMMEDIATE V_SQL;
  --------------------------------������־��Ϣ���-----------------------------
  --------------------------------��ʼ������־��Ϣ-----------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR13015',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT; 
    --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE WHERE INDEX_ID = ''OR12003''
  AND CHANNEL_ID=''BK'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4�������ڿհ׵�֤���ŵ�����
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR12003'',
                 ''86'',
                 ''BK'',
                 count(DISTINCT docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')    
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A 
 LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 WHERE STATUS IN (''2'',''4'')--2 T2���š� 4 T3����
 AND PFLAG_H=''1''
 AND to_date(updatetime,''yyyymmddhh24miss'')
 BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
 AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
';
  EXECUTE IMMEDIATE V_SQL;
  DBMS_OUTPUT.put_line(V_SQL);
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
  INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR12003',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
 --------------------------------ɾ������--------------------------------
  V_SQL := 'DELETE FROM E_MDS_IRR_INDEX_VALUE 
  WHERE INDEX_ID = ''OR12002''
  AND CHANNEL_ID=''BK'' 
  AND TO_CHAR(LOAD_DT,''yyyymmdd'') = ' || V_INDATE || '';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
  --------------------------------��������--------------------------------
  --���4���������ѷ��ſհ׵�֤ȱʧ������
  V_START := SYSDATE;
  V_SQL   := 'INSERT INTO E_MDS_IRR_INDEX_VALUE(
             INDEX_ID,
             ORG_ID,
             CHANNEL_ID,
             INDEX_VALUE,
             EVAL_DATE,
             LOAD_DT)
          SELECT ''OR12002'',
                 ''86'',
                 ''BK'',
                 count(DISTINCT docno),
                CASE WHEN TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1 =''0''
                    THEN (TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')-1)||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')+3)
                      ELSE TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''yyyy'')||''Q''||(TO_CHAR(to_date('''|| V_INDATE ||''',''yyyy-mm-dd''),''q'')-1) END,
                 TO_DATE( '''|| V_INDATE ||''',''YYYYMMDD'')
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A
 LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 WHERE  STATUS=''9''     --��ʧ
   AND SUBSTR(team,1,1)=''4''
   AND TO_DATE(UPDATETIME, ''yyyymmddhh24miss'') 
   BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
   AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
   AND PFLAG_H =''1''
   AND docno IN (
 SELECT DOCNO  
 FROM E_BDS_AFMS_AFMS_AFMS_HISTORY A 
 LEFT JOIN E_BDS_BIDM_MGECMP B
 ON A.TEAM = B.LAORIGORGCODE
 WHERE STATUS IN (''2'',''4'')--2 T2���š� 4 T3����
 AND PFLAG_H=''1''
 AND to_date(updatetime,''yyyymmddhh24miss'')
 BETWEEN to_date('''||V_EVAL_STARTTIME||''' ,''yyyymmddhh24miss'')
 AND to_date('''||V_EVAL_ENDTIME||''',''yyyymmddhh24miss'')
 )';
   DBMS_OUTPUT.put_line(V_SQL);
  EXECUTE IMMEDIATE V_SQL;
  -----------------------------------��ʼ������־��Ϣ--------------------------------
  V_RECORD_NUM := SQL%ROWCOUNT;
  V_END        := SYSDATE;
  V_RTNCODE    := '0';
  V_RTNMSG     := 'ִ�гɹ�';
   INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     'OR12002',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;  
  --------------------------------�쳣����-------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ROLLBACK;
      V_END     := SYSDATE;
      V_RTNCODE := '1';
      V_RTNMSG  := SQLERRM;
     INSERT INTO ETL_LOG_DETAIL
    (ID,
     INDEX_ID,
     SP_NAME,
     TABLE_NAME,
     START_TIME,
     END_TIME,
     DATA_DATE,
     RECORD_NUM,
     ERR_CODE,
     ERR_MSG)
  VALUES
    (SYS_GUID(),
     '',
     'SP_MDS_DOCUMENT',
     'E_MDS_IRR_INDEX_VALUE',
     V_START,
     V_END,
     V_INDATE,
     V_RECORD_NUM,
     V_RTNCODE,
     V_RTNMSG);
  COMMIT;
  --------------------------------������־��Ϣ���-----------------------------
    END;
END SP_MDS_DOCUMENT;

/

